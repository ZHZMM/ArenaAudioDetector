# -*- coding: utf-8 -*-
"""
page_settings.py —— 设置页（整合全部设置，可滚动）
"""

import tkinter as tk
from tkinter import ttk


def _scroll_area(app, parent):
    canvas = tk.Canvas(parent, highlightthickness=0)
    sb = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
    inner = ttk.Frame(canvas)
    win_id = canvas.create_window((0, 0), window=inner, anchor="nw")
    canvas.configure(yscrollcommand=sb.set)
    app.register_canvas(canvas)
    inner.bind("<Configure>",
               lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.bind("<Configure>",
                lambda e: canvas.itemconfigure(win_id, width=e.width))

    def wheel(e):
        canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
    canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", wheel))
    canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
    sb.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    return inner


def build_settings(app, parent):
    s = app.settings
    inner = _scroll_area(app, parent)

    # ================= 1. 通用 =================
    g = ttk.LabelFrame(inner, text=app.tr("s_general"), padding=12)
    g.pack(fill="x", padx=8, pady=8)

    ttk.Label(g, text=app.tr("s_language")).pack(anchor="w")
    lang_var = tk.StringVar(value=s.get("language", "auto"))
    lang_combo = ttk.Combobox(g, textvariable=lang_var, state="readonly",
                              values=["auto", "zh", "en", "ja", "ru"], width=12)
    lang_combo.pack(anchor="w", pady=(2, 6))
    ttk.Label(g, text=app.tr("s_language_auto",
                             lang=app.detected_lang),
              foreground="#888").pack(anchor="w")
    lang_combo.bind("<<ComboboxSelected>>",
                    lambda e: app.set_setting("language", lang_var.get(),
                                              rebuild=True))

    ttk.Separator(g).pack(fill="x", pady=8)
    ttk.Label(g, text=app.tr("s_theme")).pack(anchor="w")
    theme_var = tk.StringVar(value=s.get("theme_mode", "auto"))
    for code, key in (("light", "s_theme_light"),
                      ("dark", "s_theme_dark"),
                      ("auto", "s_theme_auto")):
        ttk.Radiobutton(g, text=app.tr(key), value=code,
                        variable=theme_var,
                        command=lambda: app.set_setting(
                            "theme_mode", theme_var.get(),
                            rebuild=True)).pack(anchor="w")

    ttk.Label(g, text=app.tr("s_theme_time")).pack(anchor="w", pady=(8, 2))
    trow = ttk.Frame(g)
    trow.pack(anchor="w")
    start_var = tk.StringVar(value=s.get("dark_start", "19:00"))
    end_var = tk.StringVar(value=s.get("dark_end", "07:00"))
    ttk.Entry(trow, textvariable=start_var, width=8).pack(side="left")
    ttk.Label(trow, text=" – ").pack(side="left")
    ttk.Entry(trow, textvariable=end_var, width=8).pack(side="left")
    ttk.Button(trow, text="OK",
               command=lambda: (app.set_setting("dark_start", start_var.get()),
                                app.set_setting("dark_end", end_var.get(),
                                                rebuild=True))).pack(
                side="left", padx=8)

    # ================= 2. 快捷键 =================
    h = ttk.LabelFrame(inner, text=app.tr("s_hotkey"), padding=12)
    h.pack(fill="x", padx=8, pady=8)
    hk_enable = tk.BooleanVar(value=s.get("hotkey_enabled", True))
    ttk.Checkbutton(h, text=app.tr("s_hotkey_enable"), variable=hk_enable,
                    command=lambda: app.set_setting(
                        "hotkey_enabled", hk_enable.get(),
                        hotkey=True)).pack(anchor="w")
    app.hotkey_capture_btn = ttk.Button(
        h, text=app.tr("s_hotkey_capture") + "  [" + s.get("hotkey", "") + "]",
        command=lambda: app.begin_capture_hotkey(app.hotkey_capture_btn))
    app.hotkey_capture_btn.pack(anchor="w", pady=8)

    # ================= 3. 抗环境音（农场 / 山谷） =================
    gr = ttk.LabelFrame(inner, text=app.tr("s_guard"), padding=12)
    gr.pack(fill="x", padx=8, pady=8)
    guard_var = tk.BooleanVar(value=s.get("guard_enabled", False))
    gate_var = tk.BooleanVar(value=s.get("guard_gate", False))
    spec_var = tk.BooleanVar(value=s.get("guard_spectral", True))

    def apply_guard():
        v = guard_var.get()
        app.set_setting("guard_enabled", v)
        if app.is_listening and getattr(app, "guard", None) is not None:
            app.guard.set_enabled(v)
        app._refresh_guard_button()

    ttk.Checkbutton(gr, text=app.tr("s_guard_enable"), variable=guard_var,
                    command=apply_guard).pack(anchor="w")
    ttk.Checkbutton(gr, text=app.tr("s_guard_gate"), variable=gate_var,
                    command=lambda: app.set_setting("guard_gate",
                                                    gate_var.get())).pack(
        anchor="w", pady=4)
    ttk.Checkbutton(gr, text=app.tr("s_guard_spectral"), variable=spec_var,
                    command=lambda: app.set_setting("guard_spectral",
                                                    spec_var.get())).pack(
        anchor="w")
    ttk.Label(gr, text=app.tr("s_guard_note"), wraplength=560,
              justify="left", foreground="#888").pack(anchor="w", pady=(6, 6))

    ghk_enable = tk.BooleanVar(value=s.get("guard_hotkey_enabled", True))
    ttk.Checkbutton(gr, text=app.tr("s_guard_hotkey_enable"),
                    variable=ghk_enable,
                    command=lambda: app.set_setting(
                        "guard_hotkey_enabled", ghk_enable.get(),
                        hotkey=True)).pack(anchor="w")
    app.guard_hotkey_capture_btn = ttk.Button(
        gr, text=app.tr("s_hotkey_capture") + "  ["
        + s.get("guard_hotkey", "") + "]",
        command=lambda: app.begin_capture_hotkey(
            app.guard_hotkey_capture_btn, "guard_hotkey"))
    app.guard_hotkey_capture_btn.pack(anchor="w", pady=6)

    # ================= 4. 隐私与安全 =================
    sec = ttk.LabelFrame(inner, text=app.tr("s_security"), padding=12)
    sec.pack(fill="x", padx=8, pady=8)
    cap_var = tk.BooleanVar(value=s.get("capture_protect", True))
    ttk.Checkbutton(sec, text=app.tr("s_capture_protect"), variable=cap_var,
                    command=lambda: app.set_setting("capture_protect",
                                                    cap_var.get(),
                                                    security=True)).pack(anchor="w")

    ttk.Label(sec, text=app.tr("s_proc_action")).pack(anchor="w", pady=(8, 2))
    act_var = tk.StringVar(value=s.get("protected_action", "capture"))
    for code, key in (("capture", "s_act_capture"),
                      ("overlay", "s_act_overlay"),
                      ("all", "s_act_all"),
                      ("pause", "s_act_pause")):
        ttk.Radiobutton(sec, text=app.tr(key), value=code,
                        variable=act_var,
                        command=lambda: app.set_setting(
                            "protected_action", act_var.get())).pack(anchor="w")

    ttk.Label(sec, text=app.tr("s_protected_procs"), wraplength=560,
              justify="left").pack(anchor="w", pady=(8, 4))
    proc_list = tk.Listbox(sec, height=6, relief="flat",
                           activestyle="none")
    proc_list.pack(fill="x")
    app._proc_list = proc_list
    for name in s.get("protected_processes", []):
        proc_list.insert("end", name)

    prow = ttk.Frame(sec)
    prow.pack(fill="x", pady=6)
    proc_entry = ttk.Entry(prow)
    proc_entry.pack(side="left", fill="x", expand=True)

    def add():
        v = proc_entry.get().strip()
        if v:
            app.add_protected_process(v)
            proc_entry.delete(0, "end")

    ttk.Button(prow, text=app.tr("s_add_proc"), command=add).pack(
        side="left", padx=6)
    ttk.Button(prow, text=app.tr("s_remove"),
               command=lambda: app.remove_protected_process(
                   proc_list.curselection())).pack(side="left")

    ttk.Button(inner, text=app.tr("s_reset"),
               command=app.reset_settings).pack(anchor="w", padx=8, pady=(0, 16))
