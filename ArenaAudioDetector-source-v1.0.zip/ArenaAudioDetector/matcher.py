# -*- coding: utf-8 -*-
"""
matcher.py —— 音效匹配器（在识别引擎之上做阈值与冷却判定）
================================================================
职责：
  1. 加载模板目录构建 FingerprintDB，调用 recognize_audio 得到最高相似度/区分度；
  2. 双门槛：score ≥ score_threshold 且 margin ≥ margin_threshold；
  3. 同一音效冷却时间内不重复上报。
显示结构与多语言由 items_data + i18n 负责，本模块只返回 wav 文件名与分数。
"""

import math
import time

import numpy as np

from audio_recognizer import (
    FingerprintDB,
    recognize_audio,
    _resample_linear,
    TARGET_SR,
)


class AudioMatcher:
    def __init__(self, template_dir,
                 score_threshold=0.40, margin_threshold=0.20, cooldown=2.0):
        self.db = FingerprintDB(template_dir)
        self.score_threshold = float(score_threshold)
        self.margin_threshold = float(margin_threshold)
        self.cooldown = float(cooldown)
        self._last_match = {}

    def match(self, audio, sr):
        """返回 dict(file, score, margin) 或 None。"""
        y = np.asarray(audio, dtype=np.float32)
        if y.ndim > 1:
            y = y.mean(axis=1)
        if len(y) < 1024:
            return None

        # 关键：统一重采样到分析采样率 22050，否则频带映射错位、指纹失配
        if sr != TARGET_SR:
            y = _resample_linear(y.astype(np.float64), sr,
                                 TARGET_SR).astype(np.float32)

        try:
            name, score, second, margin = recognize_audio(y, TARGET_SR, self.db)
        except Exception:
            return None

        if not all(math.isfinite(v) for v in (score, second, margin)):
            return None
        if score < self.score_threshold or margin < self.margin_threshold:
            return None

        now = time.time()
        last = self._last_match.get(name, 0)
        if now - last < self.cooldown:
            return None

        self._last_match[name] = now
        return {"file": name, "score": score, "margin": margin}

    @property
    def template_count(self):
        return len(self.db.names)
