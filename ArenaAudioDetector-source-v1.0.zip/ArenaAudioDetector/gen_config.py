# -*- coding: utf-8 -*-
"""生成 config.json（新版：大金目录明细 + 小紫标记 //）"""

import json

items = {
    # 第1组：每个物品音频不同（g1_03/g1_04 合并显示为同一物品槽）
    "g1_01.wav": "🏺 古董茶壶",
    "g1_02.wav": "🏺 花瓶",
    "g1_03.wav": "💎 宝石项链/卡莫纳之心",
    "g1_04.wav": "💎 宝石项链/卡莫纳之心",
    "g1_05.wav": "🦁 狮子(6格)",

    # 第2~6组：组内音频相同 → 显示组内详细目录；"//"开头 = 小紫（紫色显示）
    "g2_common.wav": {
        "title": "第二组大金",
        "items": ["机密文件", "热成像模块", "目标定位模块", "天线", "炮队镜",
                  "//示波器", "游戏机"],
    },
    "g3_common.wav": {
        "title": "第三组大金",
        "items": ["三轴陀螺仪", "赫美拉菜单", "整列镜片", "胶囊电视", "混沌质",
                  "承天浑仪", "量子2000", "里拉琴", "原型机模块", "//钢筋剪",
                  "液压扳手", "电钻", "工具套组", "炮弹"],
    },
    "g4_common.wav": {
        "title": "第四组大金",
        "items": ["大金天命泥板", "理想国", "//钢管", "汽车蓄电池", "钛合金钢板"],
    },
    "g5_common.wav": {
        "title": "第五组大金",
        "items": ["大金黄金面具", "航天导航仪", "孔雀羽山", "真实矩阵", "鸟笼",
                  "黎明", "机械手臂", "//航太实验箱", "血糖仪套装", "维塞尔日记",
                  "行星之子", "非线性探测仪", "军用工具包"],
    },
    "g6_common.wav": {
        "title": "第六组大金",
        "items": ["白蛇金像", "光电模型", "盛宴雕像", "//石膏雕像", "X7-L密码机"],
    },
}

config = {
    "sample_rate": 48000,
    "chunk_duration_ms": 250,
    "buffer_seconds": 2.0,
    "match_threshold": 0.40,
    "min_margin": 0.20,
    "cooldown_ms": 2000,
    "items": items,
}

with open("config.json", "w", encoding="utf-8") as f:
    json.dump(config, f, ensure_ascii=False, indent=2)

print("✅ config.json 已生成")
print(f"✅ 共 {len(items)} 个音频映射")
for k, v in items.items():
    if isinstance(v, dict):
        print(f"   {k} → {v['title']}（{len(v['items'])} 项）")
    else:
        print(f"   {k} → {v}")
