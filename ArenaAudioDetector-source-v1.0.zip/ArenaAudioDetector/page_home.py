﻿# -*- coding: utf-8 -*-
"""
page_home.py —— 主页（老监听界面 + 新增“大金清单”表格）
"""

import tkinter as tk
from tkinter import ttk

from items_data import ITEM_MAP


def build_home(app, parent):
    t = app.theme

    # ============ 监听设置 ============
    box = ttk.LabelFrame(parent, text=app.tr("home_listen_setup"), padding=12)
    box.pack(fill="x", pady=(4, 8))

    # 设备行
    row = ttk.Frame(box)
    row.pack(fill="x", pady=(0, 4))
    ttk.Label(row, text=app.tr("home_device")).pack(side="left")
    app.source_combo = ttk.Combobox(row, textvariable=app.source_var,
                                   state="readonly", width=58)
    app.source_combo.pack(side="left", padx=6)
    app.source_combo.bind("<<ComboboxSelected>>", app.on_source_selected)
    ttk.Button(row, text=app.tr("home_refresh"),
               command=app.refresh_sources).pack(side="left")

    ttk.Label(box, text=app.tr("home_device_hint"), wraplength=560,
              justify="left").pack(fill="x", pady=(2, 8))

    # 灵敏度行
    row2 = ttk.Frame(box)
    row2.pack(fill="x")
    ttk.Label(row2, text=app.tr("home_sensitivity")).pack(side="left")
    ttk.Scale(row2, from_=0, to=100, orient="horizontal",
              variable=app.sensitivity_var, length=300,
              command=app.on_sensitivity_change).pack(side="left", padx=8)
    ttk.Label(row2, textvariable=app.sens_detail_var).pack(side="left")
    ttk.Label(box, text=app.tr("home_sens_hint"), wraplength=560,
              justify="left").pack(fill="x", pady=(4, 0))

    # ============ 控制行 ============
    ctl = ttk.Frame(parent)
    ctl.pack(fill="x", pady=8)
    app.btn_toggle = ttk.Button(ctl, text=app.tr("home_start"),
                                style="Accent.TButton",
                                command=app.toggle_listening)
    app.btn_toggle.pack(side="left")
    app.btn_guard = ttk.Button(ctl, text=app.tr("home_guard"),
                               command=app.toggle_guard)
    app.btn_guard.pack(side="left", padx=(8, 0))
    app._refresh_guard_button()
    ttk.Label(ctl, textvariable=app.status_var).pack(side="left", padx=14)

    # ============ Notebook：监听 + 大金清单 ============
    nb = ttk.Notebook(parent)
    nb.pack(fill="both", expand=True)

    # —— Tab 监听（电平 + 日志，老界面） ——
    tab_listen = ttk.Frame(nb, padding=8)
    nb.add(tab_listen, text=app.tr("tab_listen"))

    app.level_canvas = tk.Canvas(tab_listen, height=16, highlightthickness=1)
    app.level_canvas.pack(fill="x", pady=(0, 8))
    app.register_canvas(app.level_canvas)

    log_wrap = ttk.Frame(tab_listen)
    log_wrap.pack(fill="both", expand=True)
    app.log_widget = tk.Text(log_wrap, height=14, wrap="word",
                             relief="flat", font=("Consolas", 9),
                             padx=6, pady=4)
    sb = ttk.Scrollbar(log_wrap, orient="vertical",
                       command=app.log_widget.yview)
    app.log_widget.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y")
    app.log_widget.pack(side="left", fill="both", expand=True)
    app.register_text(app.log_widget)
    app.log_widget.tag_configure("err", foreground=t["red"])
    app.log_widget.tag_configure("ok", foreground=t["green"])
    app.log_widget.tag_configure("info", foreground=t["fg_dim"])
    app.log_widget.configure(state="disabled")

    # —— Tab 大金清单（Name list 表格） ——
    tab_list = ttk.Frame(nb, padding=8)
    nb.add(tab_list, text=app.tr("tab_namelist"))

    cols = ("group", "item", "rarity")
    tree = ttk.Treeview(tab_list, columns=cols, show="headings")
    tree.heading("group", text=app.tr("nl_group"))
    tree.heading("item", text=app.tr("nl_item"))
    tree.heading("rarity", text=app.tr("nl_rarity"))
    tree.column("group", width=150, anchor="w", stretch=False)
    tree.column("item", width=300, anchor="w", stretch=True)
    tree.column("rarity", width=80, anchor="center", stretch=False)

    tree.tag_configure("red", foreground=t["red"])
    tree.tag_configure("gold", foreground=t["gold"])
    tree.tag_configure("purple", foreground=t["purple"])

    for wav, entry in ITEM_MAP.items():
        if entry["kind"] == "single":
            ckey = entry.get("color", "red")
            tree.insert("", "end",
                        values=(app.tr("nl_g1"),
                                app.i18n.item(entry["item"]),
                                app.tr("nl_" + ckey)),
                        tags=(ckey,))
        else:
            gname = app.i18n.group(entry["group"])
            for key, ckey in entry["items"]:
                tree.insert("", "end",
                            values=(gname, app.i18n.item(key),
                                    app.tr("nl_" + ckey)),
                            tags=(ckey,))

    lsb = ttk.Scrollbar(tab_list, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=lsb.set)
    lsb.pack(side="right", fill="y")
    tree.pack(side="left", fill="both", expand=True)

