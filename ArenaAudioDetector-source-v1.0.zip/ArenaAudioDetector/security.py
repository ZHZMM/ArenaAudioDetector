# -*- coding: utf-8 -*-
"""
security.py —— 隐私与安全防护
================================================================
本软件基于“监听系统音频”原理，为防止其画面/存在被其他应用识别或利用：

1) 窗口防屏幕捕获（SetWindowDisplayAffinity + WDA_EXCLUDEFROMCAPTURE）：
   主窗口与识别浮窗在截图、录屏、屏幕共享中变为不可见（Win10 2004+）。

2) 受保护进程监控：
   周期性枚举系统进程，一旦名单内进程（默认含《暗区突围：无限》主进程
   UAGame.exe 及其启动器/反作弊）开始运行，自动按用户设定隐藏窗口或暂停
   监听；进程退出后恢复。其他进程由用户在“设置”中手动添加。
"""

import ctypes
import ctypes.wintypes as wt
import threading
import time

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

# SetWindowDisplayAffinity
WDA_NONE = 0x00
WDA_MONITOR = 0x01
WDA_EXCLUDEFROMCAPTURE = 0x11

GA_ROOT = 2

# Toolhelp
TH32CS_SNAPPROCESS = 0x00000002


class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wt.DWORD),
        ("cntUsage", wt.DWORD),
        ("th32ProcessID", wt.DWORD),
        ("th32DefaultHeapID", ctypes.c_void_p),
        ("th32ModuleID", wt.DWORD),
        ("cntThreads", wt.DWORD),
        ("th32ParentProcessID", wt.DWORD),
        ("pcPriClassBase", ctypes.c_long),
        ("dwFlags", wt.DWORD),
        ("szExeFile", ctypes.c_wchar * 260),
    ]


def widget_hwnd(widget):
    """从 tk 控件取得顶层窗口句柄。"""
    try:
        wid = int(widget.winfo_id())
        hwnd = user32.GetAncestor(wid, GA_ROOT)
        return int(hwnd) if hwnd else wid
    except Exception:
        return None


def set_window_capture_protection(hwnd, enable):
    """对指定窗口设置/解除防屏幕捕获。返回是否成功。"""
    if not hwnd:
        return False
    affinity = WDA_EXCLUDEFROMCAPTURE if enable else WDA_NONE
    return bool(user32.SetWindowDisplayAffinity(wt.HWND(hwnd), affinity))


def enum_process_names():
    """返回当前运行的进程名集合（小写）。"""
    names = set()
    snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if not snap or snap == ctypes.c_void_p(-1).value:
        return names
    pe = PROCESSENTRY32W()
    pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
    if kernel32.Process32FirstW(snap, ctypes.byref(pe)):
        while True:
            names.add(pe.szExeFile.lower())
            if not kernel32.Process32NextW(snap, ctypes.byref(pe)):
                break
    kernel32.CloseHandle(snap)
    return names


def _normalize(name):
    n = str(name).strip().lower()
    if n and not n.endswith(".exe"):
        n += ".exe"
    return n


def match_processes(targets, live_names):
    """返回命中的目标名列表（精确匹配，兼容省略 .exe 的写法）。"""
    hit = []
    for t in targets:
        n = _normalize(t)
        if not n:
            continue
        bare = n[:-4]
        if n in live_names or any(x == n or x[:-4] == bare
                                 for x in live_names):
            hit.append(n)
    return sorted(set(hit))


class ProcessMonitor:
    """后台轮询进程，状态变化时回调 on_change(present, matched)。"""

    def __init__(self, targets, on_change, interval=1.5):
        self.targets = [_normalize(t) for t in targets]
        self.on_change = on_change
        self.interval = float(interval)
        self._want = False
        self.thread = None
        self._last = None

    def start(self):
        self.stop()
        self._want = True
        self._last = None
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        self._want = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.0)
        self.thread = None

    def _run(self):
        while self._want:
            try:
                live = enum_process_names()
                matched = match_processes(self.targets, live)
                present = bool(matched)
                if present != self._last:
                    self._last = present
                    if self.on_change:
                        try:
                            self.on_change(present, matched)
                        except Exception:
                            pass
            except Exception:
                pass
            time.sleep(self.interval)


class SecurityManager:
    def __init__(self):
        self.monitor = None
        self._protected_hwnds = []

    # —— 窗口防捕获 ——
    def register_window(self, widget):
        hwnd = widget_hwnd(widget)
        if hwnd and hwnd not in self._protected_hwnds:
            self._protected_hwnds.append(hwnd)
        return hwnd

    def apply_capture_protection(self, enable):
        ok = True
        for hwnd in list(self._protected_hwnds):
            if not set_window_capture_protection(hwnd, enable):
                ok = False
        return ok

    # —— 进程监控 ——
    def start_process_monitor(self, targets, on_change, interval=1.5):
        self.stop_process_monitor()
        self.monitor = ProcessMonitor(targets, on_change, interval)
        self.monitor.start()

    def stop_process_monitor(self):
        if self.monitor:
            self.monitor.stop()
            self.monitor = None

    def shutdown(self):
        self.stop_process_monitor()
        try:
            for hwnd in list(self._protected_hwnds):
                set_window_capture_protection(hwnd, False)
        except Exception:
            pass
