﻿# -*- coding: utf-8 -*-
"""BETA 打包版自检（隐藏诊断模式）：在真实 _MEIPASS 环境验证
资源加载、模板、算法、WASAPI 环回，并做一次“播放→环回采集→识别”闭环。
正常双击（不带 --selftest）不会进入此模式。"""
import os
import sys
import time
import wave
from collections import deque

import numpy as np

import app_paths
from audio_capture import AudioCapture, list_sources
from matcher import AudioMatcher
from audio_recognizer import load_wav, recognize_audio


def run(report_path):
    lines = []

    def log(m):
        lines.append(str(m))
        print(m, flush=True)

    log("=== ArenaAudioDetector BETA self-test ===")
    log("time: " + time.strftime("%Y-%m-%d %H:%M:%S"))
    log("frozen: %s" % getattr(sys, "frozen", False))
    tdir = app_paths.resource_dir()
    log("resource dir: %s" % tdir)

    # 1) 配置与模板（真实打包资源）
    cfg = app_paths.resource_path("config.json")
    log("[1] config.json exists: %s" % os.path.exists(cfg))
    matcher = AudioMatcher(tdir)
    db = matcher.db
    n_t = len(db.names)
    log("[1] templates loaded: %d" % n_t)

    # 2) 自匹配（加载原始 wav 再识别）
    ok = 0
    worst = 1.0
    for i, name in enumerate(db.names):
        y, sr = load_wav(db.paths[i])
        n2, score, second, margin = recognize_audio(y, sr, db)
        if n2 == name:
            ok += 1
            worst = min(worst, score)
    log("[2] self-match: %d/%d (worst %.3f)" % (ok, n_t, worst))

    # 3) 音频设备 / 环回
    srcs = list_sources()
    loops = [s for s in srcs if s["kind"] == "loopback"]
    log("[3] audio sources: %d, loopback sources: %d" % (len(srcs), len(loops)))
    default_loop = next((s for s in loops if s.get("default")),
                        loops[0] if loops else None)
    if default_loop:
        log("[3] default loopback: %s @ %dHz"
            % (default_loop["name"], default_loop["sr"]))

    # 4) 实时环回闭环：播放 g5_common → 环回采集 → 识别（正常阈值）
    loop_pass = False
    best = None
    if default_loop and n_t:
        try:
            wav_path = app_paths.resource_path("g5_common.wav")
            with wave.open(wav_path) as w:
                raw = w.readframes(w.getnframes())
                psr = w.getframerate(); ch = w.getnchannels()
            play = np.frombuffer(raw, dtype=np.int16).astype(np.float32) \
                .reshape(-1, ch) / 32768.0

            import sounddevice as sd
            cap = AudioCapture(default_loop)
            cap.start()
            time.sleep(0.4)
            sd.play(play, psr)          # 非阻塞播放

            sr = cap.samplerate
            buf = deque()
            t0 = time.time()
            while time.time() - t0 < 3.2:
                chunk = cap.get_audio_chunk(0.5)
                if chunk is not None and len(chunk):
                    buf.append(chunk)
                    total = sum(len(c) for c in buf)
                    while total > sr * 2.0 and len(buf) > 1:
                        total -= len(buf.popleft())
                    if total > sr * 0.5:
                        seg = np.concatenate(list(buf))
                        r = matcher.match(seg, sr)
                        if r and (best is None or r["score"] > best["score"]):
                            best = r
            cap.stop()
            sd.stop()
            if best:
                loop_pass = best["file"] == "g5_common.wav"
                log("[4] loopback best: %s score=%.3f margin=%.3f"
                    % (best["file"], best["score"], best["margin"]))
            else:
                log("[4] loopback: no match produced")
        except Exception as e:
            import traceback
            log("[4] loopback ERROR: %r\n%s" % (e, traceback.format_exc()))
    else:
        log("[4] loopback skipped (no device/templates)")

    all_ok = (os.path.exists(cfg) and n_t >= 10 and ok == n_t
              and default_loop is not None and loop_pass)
    log("=== RESULT: %s ===" % ("PASS" if all_ok else "CHECK"))

    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return all_ok



