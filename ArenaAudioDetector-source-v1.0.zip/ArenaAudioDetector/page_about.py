# -*- coding: utf-8 -*-
"""
page_about.py —— 关于页（开发者名单）
"""

import tkinter as tk
from tkinter import ttk


def build_about(app, parent):
    t = app.theme
    wrap = ttk.Frame(parent, padding=24)
    wrap.pack(fill="both", expand=True)

    ttk.Label(wrap, text=app.tr("app_title"),
              font=("Segoe UI", 20, "bold")).pack(anchor="w")
    tag = ttk.Label(wrap, text=app.tr("version_tag"),
                    foreground=t["gold"])
    tag.pack(anchor="w", pady=(2, 12))

    ttk.Label(wrap, text=app.tr("about_desc"), wraplength=560,
              justify="left").pack(anchor="w", pady=(0, 16))

    box = ttk.LabelFrame(wrap, text=app.tr("about_dev"), padding=14)
    box.pack(fill="x")

    row = ttk.Frame(box)
    row.pack(fill="x", pady=2)
    ttk.Label(row, text=app.tr("about_github") + ":", width=10).pack(side="left")
    gh = tk.Label(row, text="ZHZHMM", fg=t["accent"],
                  bg=t["bg2"], cursor="hand2", padx=6)
    gh.pack(side="left")

    row2 = ttk.Frame(box)
    row2.pack(fill="x", pady=(6, 2))
    ttk.Label(row2, text=app.tr("about_author"), width=10).pack(side="left")
    ttk.Label(row2, text="ND").pack(side="left")

    ttk.Label(wrap, text=app.tr("about_disclaimer"), wraplength=560,
              justify="left", foreground=t["fg_dim"]).pack(
                anchor="w", pady=(18, 0))
