# -*- coding: utf-8 -*-
"""
main.py —— ArenaAudioDetector（暗区大金音效识别）BETA 主程序
================================================================
新版特性：
  · WASAPI 环回采集（默认，直接抓播放设备系统声，彻底解决抓不到游戏声）；
  · 侧边栏布局：主页（老界面 + 大金清单表格）/ 设置 / 关于；
  · 多语言 中/英/日/俄（跟随系统，失败默认英文，可手动切换）；
  · 浅色/深色主题（按系统时间自动切换，可手动覆盖）；
  · 可配置全局开始/停止快捷键（默认 Ctrl+Alt+S）；
  · 隐私安全：窗口防屏幕捕获 + 受保护进程联动（默认含暗区突围：无限）；
  · 抗环境音能力准备（默认关闭）。
"""

import os
import sys
import json
import time
import queue
import threading
import traceback
from collections import deque
from datetime import datetime

import numpy as np
import tkinter as tk
from tkinter import ttk

from app_paths import resource_dir, resource_path
from settings_store import SettingsStore
from i18n import I18n, detect_system_language, LANGS
from theme import Theme
from audio_capture import list_sources
from matcher import AudioMatcher
from audio_guard import AudioGuard
from hotkey import (GlobalHotkey, MOD_CONTROL, MOD_ALT, MOD_SHIFT,
                    key_to_vk, format_hotkey)
from security import SecurityManager
from overlay import OverlayWindow
from items_data import entry_for_wav

from page_home import build_home
from page_settings import build_settings
from page_about import build_about


# 无控制台打包时 stdout 可能为 None
class _Null:
    def write(self, s):
        pass

    def flush(self):
        pass


if sys.stdout is None:
    sys.stdout = _Null()
if sys.stderr is None:
    sys.stderr = _Null()


def now_str():
    return datetime.now().strftime("%H:%M:%S")


class App:
    def __init__(self):
        # ---------- 设置 / 语言 / 主题 ----------
        self.settings = SettingsStore()
        self.detected_lang = detect_system_language()
        self._refresh_locale()
        self.theme = Theme.from_settings(self.settings.all())

        # ---------- 运行状态 ----------
        self.is_listening = False
        self.paused = False
        self.capture = None
        self.matcher = None
        self.guard = None
        self.match_thread = None
        self.overlay = None
        self.buffer = deque(maxlen=8)
        self.trigger_level = 0.011
        self._last_level = 0.0
        self.last_trigger = 0.0
        self.sources = []
        self.selected_source = None
        self.current_page = "home"

        # ---------- 主窗口 ----------
        self.root = tk.Tk()
        self.root.title("ArenaAudioDetector")
        self.root.geometry("780x700")
        self.root.minsize(700, 620)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        # ---------- tk 变量 ----------
        self.source_var = tk.StringVar()
        self.sensitivity_var = tk.IntVar(
            value=int(self.settings.get("sensitivity", 80)))
        self.sens_detail_var = tk.StringVar()
        self.status_var = tk.StringVar()

        self._texts = []
        self._canvases = []
        self.ui_q = queue.Queue()

        # ---------- 安全 / 快捷键 ----------
        self.security = SecurityManager()
        self.security.register_window(self.root)
        self.global_hotkey = GlobalHotkey(
            on_trigger=lambda: self.ui_q.put(("toggle",)),
            on_status=self._on_hotkey_status)
        self.guard_hotkey = GlobalHotkey(
            on_trigger=lambda: self.ui_q.put(("toggle_guard",)),
            on_status=self._on_guard_hotkey_status,
            hot_id=0xB002)

        # ---------- 异常钩子 ----------
        sys.excepthook = self._sys_hook
        threading.excepthook = lambda a: self._log(
            "后台线程异常:\n" + "".join(traceback.format_exception(
                a.exc_type, a.exc_value, a.exc_traceback)), "err")
        self.root.report_callback_exception = self._tk_hook

        # ---------- 构建 ----------
        self.configure_styles()
        self._build_shell()

        # 首次启动：必须同意用户协议；拒绝则退出程序
        if not self.settings.get("license_agreed", False):
            from license_dialog import LicenseDialog
            self.root.withdraw()
            dlg = LicenseDialog(self)
            self.root.wait_window(dlg.win)
            if not dlg.accepted:
                self.root.destroy()
                return
            self.root.deiconify()

        self.show_page("home")
        self.refresh_sources()
        self.on_sensitivity_change()
        self._start_services()

        self.poll()

    # ================================================================
    # 语言 / 主题 / 样式
    # ================================================================
    def _refresh_locale(self):
        lang = self.settings.get("language", "auto")
        code = self.detected_lang if lang == "auto" else lang
        self.i18n = I18n(code)

    def tr(self, key, **kw):
        return self.i18n.t(key, **kw)

    def configure_styles(self):
        t = self.theme
        st = ttk.Style(self.root)
        st.theme_use("clam")
        st.configure(".", background=t["bg"], foreground=t["fg"],
                     bordercolor=t["border"])
        st.configure("TFrame", background=t["bg"])
        st.configure("TLabel", background=t["bg"], foreground=t["fg"])
        st.configure("TLabelframe", background=t["bg"],
                     bordercolor=t["border"])
        st.configure("TLabelframe.Label", background=t["bg"],
                     foreground=t["gold"])
        st.configure("TButton", background=t["bg3"], foreground=t["fg"],
                     bordercolor=t["border"], focusthickness=0, padding=6)
        st.map("TButton", background=[("active", t["bg_hover"])])
        st.configure("Accent.TButton", background=t["accent"],
                     foreground=t["accent_fg"], padding=8,
                     font=("Segoe UI", 11, "bold"))
        st.map("Accent.TButton",
               background=[("active", t["accent_hover"])])
        st.configure("TCombobox", fieldbackground=t["bg2"],
                     background=t["bg3"], foreground=t["fg"],
                     arrowcolor=t["fg_dim"], bordercolor=t["border"],
                     lightcolor=t["border"], darkcolor=t["border"])
        st.map("TCombobox",
               fieldbackground=[("readonly", t["bg2"])],
               foreground=[("readonly", t["fg"])])
        st.configure("TEntry", fieldbackground=t["bg2"],
                     foreground=t["fg"], bordercolor=t["border"],
                     insertcolor=t["fg"])
        st.configure("TNotebook", background=t["bg"],
                     bordercolor=t["border"])
        st.configure("TNotebook.Tab", background=t["bg3"],
                     foreground=t["fg_dim"], padding=[14, 6])
        st.map("TNotebook.Tab",
               background=[("selected", t["bg2"])],
               foreground=[("selected", t["fg"])])
        st.configure("Treeview", background=t["canvas_bg"],
                     fieldbackground=t["canvas_bg"], foreground=t["fg"],
                     bordercolor=t["border"])
        st.configure("Treeview.Heading", background=t["bg3"],
                     foreground=t["fg"], bordercolor=t["border"])
        st.map("Treeview.Heading",
               background=[("active", t["bg_hover"])])
        st.configure("TCheckbutton", background=t["bg"],
                     foreground=t["fg"])
        st.map("TCheckbutton", background=[("active", t["bg"])])
        st.configure("TRadiobutton", background=t["bg"],
                     foreground=t["fg"])
        st.map("TRadiobutton", background=[("active", t["bg"])])
        st.configure("Horizontal.TScale", background=t["bg"],
                     troughcolor=t["bg2"])
        st.configure("TScrollbar", background=t["bg3"],
                     troughcolor=t["bg"], arrowcolor=t["fg_dim"],
                     bordercolor=t["border"])
        st.configure("Sidebar.TButton", background=t["bg_sidebar"],
                     foreground=t["fg_dim"], bordercolor=t["bg_sidebar"],
                     font=("Segoe UI", 11), padding=10)
        st.map("Sidebar.TButton",
               background=[("active", t["bg_hover"])],
               foreground=[("active", t["fg"])])
        st.configure("SidebarActive.TButton",
                     background=t["nav_active"], foreground=t["fg"],
                     font=("Segoe UI", 11, "bold"), padding=10)

    # ---------------- 外壳（侧边栏 + 内容） ----------------
    def _build_shell(self):
        t = self.theme
        self.sidebar = tk.Frame(self.root, bg=t["bg_sidebar"], width=160)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        self.content = ttk.Frame(self.root, padding=10)
        self.content.pack(side="left", fill="both", expand=True)

        self.nav_buttons = {}
        for name, key in (("home", "nav_home"),
                          ("settings", "nav_settings"),
                          ("about", "nav_about")):
            b = tk.Button(self.sidebar, text=self.tr(key),
                          relief="flat", bd=0, anchor="w",
                          cursor="hand2",
                          command=lambda n=name: self.show_page(n))
            b.pack(fill="x", padx=8, pady=4)
            self.nav_buttons[name] = b

        tk.Label(self.sidebar, text="v1.0", bg=t["bg_sidebar"],
                 fg=t["gold"], font=("Segoe UI", 9)).pack(
                    side="bottom", pady=12)

        self.pages = {}
        for name, fn in (("home", build_home),
                         ("settings", build_settings),
                         ("about", build_about)):
            frame = ttk.Frame(self.content)
            self.pages[name] = frame
            fn(self, frame)

    def show_page(self, name):
        self.current_page = name
        t = self.theme
        for n, b in self.nav_buttons.items():
            if n == name:
                b.configure(bg=t["nav_active"], fg=t["fg"],
                            font=("Segoe UI", 11, "bold"))
            else:
                b.configure(bg=t["bg_sidebar"], fg=t["fg_dim"],
                            font=("Segoe UI", 11))
        for n, f in self.pages.items():
            f.pack_forget()
        self.pages[name].pack(fill="both", expand=True)

    def rebuild(self):
        self._refresh_locale()
        self.theme = Theme.from_settings(self.settings.all())
        for w in list(self.sidebar.winfo_children()):
            w.destroy()
        for w in list(self.content.winfo_children()):
            w.destroy()
        self._texts, self._canvases = [], []
        self.configure_styles()
        self.sidebar.configure(bg=self.theme["bg_sidebar"])
        self.nav_buttons = {}
        for name, key in (("home", "nav_home"),
                          ("settings", "nav_settings"),
                          ("about", "nav_about")):
            b = tk.Button(self.sidebar, text=self.tr(key),
                          relief="flat", bd=0, anchor="w",
                          cursor="hand2",
                          command=lambda n=name: self.show_page(n))
            b.pack(fill="x", padx=8, pady=4)
            self.nav_buttons[name] = b
        tk.Label(self.sidebar, text="v1.0",
                 bg=self.theme["bg_sidebar"], fg=self.theme["gold"],
                 font=("Segoe UI", 9)).pack(side="bottom", pady=12)

        self.pages = {}
        for name, fn in (("home", build_home),
                         ("settings", build_settings),
                         ("about", build_about)):
            frame = ttk.Frame(self.content)
            self.pages[name] = frame
            fn(self, frame)
        self.show_page(self.current_page)
        if self.overlay:
            self.overlay.redraw()
        self._apply_window_protection()

    # ---------------- 文本/画布登记（创建即上色） ----------------
    def register_text(self, w):
        w.configure(bg=self.theme["canvas_bg"], fg=self.theme["fg"],
                    insertbackground=self.theme["fg"])
        self._texts.append(w)

    def register_canvas(self, w):
        w.configure(bg=self.theme["canvas_bg"],
                    highlightbackground=self.theme["border"])
        self._canvases.append(w)

    # ================================================================
    # 音频源
    # ================================================================
    def refresh_sources(self):
        try:
            self.sources = list_sources()
        except Exception as e:
            self.sources = []
            self._log("枚举音频源失败: %s" % e, "err")

        labels = []
        for s in self.sources:
            icon = "🔊" if s["kind"] == "loopback" else "🎤"
            star = " ★" if s.get("default") else ""
            labels.append("%s %s%s" % (icon, s["name"], star))
        if hasattr(self, "source_combo"):
            self.source_combo.configure(values=labels)

        # 选中：记忆的源 > 默认 loopback > 第一个
        chosen = -1
        saved = self.settings.get("selected_source")
        if saved:
            for i, s in enumerate(self.sources):
                if s["kind"] == saved.get("kind") and \
                        s["index"] == saved.get("index"):
                    chosen = i
                    break
        if chosen < 0:
            chosen = next((i for i, s in enumerate(self.sources)
                           if s.get("default")), 0 if self.sources else -1)
        if chosen >= 0:
            self.selected_source = self.sources[chosen]
            if hasattr(self, "source_combo"):
                self.source_combo.current(chosen)
        else:
            self.selected_source = None
            self.source_var.set(self.tr("log_no_device"))
        self._log(self.tr("log_devices_found", n=len(self.sources)), "info")

    def on_source_selected(self, event=None):
        i = self.source_combo.current()
        if 0 <= i < len(self.sources):
            self.selected_source = self.sources[i]
            self.settings.update(selected_source={
                "kind": self.selected_source["kind"],
                "index": self.selected_source["index"]})

    # ---------------- 灵敏度 ----------------
    def on_sensitivity_change(self, event=None):
        s = int(self.sensitivity_var.get())
        self.trigger_level = 0.05 - 0.049 * s / 100.0
        self.sens_detail_var.set(
            self.tr("home_sens_value", v=s,
                    r="%.3f" % self.trigger_level))
        self.settings.update(sensitivity=s)

    # ================================================================
    # 设置变更
    # ================================================================
    def set_setting(self, key, value, rebuild=False, hotkey=False,
                    security=False):
        self.settings.update(**{key: value})
        if hotkey:
            self._reload_hotkey()
        if security:
            self._apply_window_protection()
        if rebuild:
            self.rebuild()

    def reset_settings(self):
        self.settings.reset()
        self.sensitivity_var.set(int(self.settings.get("sensitivity", 80)))
        self._reload_hotkey()
        self._reload_process_monitor()
        self.rebuild()

    def add_protected_process(self, name):
        n = name.strip().lower()
        if not n.endswith(".exe"):
            n += ".exe"
        lst = self.settings.get("protected_processes", [])
        if n not in lst:
            lst = lst + [n]
            self.settings.update(protected_processes=lst)
            if hasattr(self, "_proc_list"):
                self._proc_list.insert("end", n)
            self._reload_process_monitor()

    def remove_protected_process(self, selection):
        if not selection:
            return
        idx = selection[0]
        lst = list(self.settings.get("protected_processes", []))
        if 0 <= idx < len(lst):
            lst.pop(idx)
            self.settings.update(protected_processes=lst)
            self._proc_list.delete(idx)
            self._reload_process_monitor()

    # ================================================================
    # 全局快捷键
    # ================================================================
    def _start_services(self):
        self._reload_hotkey()
        self._apply_window_protection()
        self._reload_process_monitor()

    def _reload_hotkey(self):
        self.global_hotkey.stop()
        if self.settings.get("hotkey_enabled", True):
            self.global_hotkey.start(self.settings.get("hotkey",
                                                      "Ctrl+Alt+S"))
        self.guard_hotkey.stop()
        if self.settings.get("guard_hotkey_enabled", True):
            self.guard_hotkey.start(self.settings.get("guard_hotkey",
                                                      "Ctrl+Alt+G"))

    def _on_hotkey_status(self, ok, hotkey, err):
        if ok:
            self._log(self.tr("hk_registered", hk=hotkey), "info")
        else:
            self._log(self.tr("hk_failed", hk=hotkey), "err")

    def _on_guard_hotkey_status(self, ok, hotkey, err):
        self._on_hotkey_status(ok, hotkey, err)

    def begin_capture_hotkey(self, btn, setting_key="hotkey"):
        btn.config(text=self.tr("s_hotkey_capture"))

        def handler(e):
            mods = 0
            if e.state & 0x004:
                mods |= MOD_CONTROL
            if e.state & 0x08:
                mods |= MOD_ALT
            if e.state & 0x001:
                mods |= MOD_SHIFT
            k = e.keysym
            if k in ("Control_L", "Control_R", "Alt_L", "Alt_R",
                     "Shift_L", "Shift_R"):
                return
            vk = key_to_vk(k)
            if vk is None or mods == 0:
                return
            hk = format_hotkey(mods, vk)
            self.root.unbind("<KeyPress>")
            self.set_setting(setting_key, hk, hotkey=True)
            btn.config(text=self.tr("s_hotkey_capture") + "  [" + hk + "]")

        self.root.bind("<KeyPress>", handler)
        self.root.focus_force()

    # ================================================================
    # 安全防护
    # ================================================================
    def _apply_window_protection(self):
        enable = bool(self.settings.get("capture_protect", True))
        self.security.apply_capture_protection(enable)

    def _reload_process_monitor(self):
        names = self.settings.get("protected_processes", [])
        self.security.start_process_monitor(names,
                                           self.on_protected_state)

    def on_protected_state(self, present, matched):
        action = self.settings.get("protected_action", "capture")
        if present:
            if action == "pause":
                self.paused = True
                self.ui_q.put(("log", self.tr("protected_hide"), "info"))
            elif action in ("overlay", "all"):
                if self.overlay:
                    self.overlay.hide()
                if action == "all":
                    self.root.withdraw()
                self.ui_q.put(("log", self.tr("protected_hide"), "info"))
            # capture（默认）：仅靠防捕获，窗口保持显示，不打“已隐藏”日志
        else:
            self.paused = False
            if action == "all":
                self.root.deiconify()
            if self.is_listening and action in ("overlay", "all") and \
                    self.overlay:
                self.overlay.show()
            if action in ("overlay", "all", "pause"):
                self.ui_q.put(("log", self.tr("protected_show"), "info"))

    # ================================================================
    # 监听生命周期
    # ================================================================
    def toggle_listening(self):
        if self.is_listening:
            self.stop_listening()
        else:
            self.start_listening()

    def toggle_guard(self):
        """切换抗环境音总开关（农场/山谷）。"""
        newv = not bool(self.settings.get("guard_enabled", False))
        self.set_setting("guard_enabled", newv)
        if self.is_listening and getattr(self, "guard", None) is not None:
            self.guard.set_enabled(newv)
        self._log(self.tr("guard_on" if newv else "guard_off"), "info")
        self._refresh_guard_button()

    def _refresh_guard_button(self):
        btn = getattr(self, "btn_guard", None)
        if btn is None:
            return
        on = bool(self.settings.get("guard_enabled", False))
        btn.config(text=self.tr("home_guard_on" if on else "home_guard"))

    def start_listening(self):
        if self.is_listening:
            return
        if self.selected_source is None:
            self._log(self.tr("log_select_source"), "err")
            return
        try:
            cfg = {}
            try:
                with open(resource_path("config.json"),
                          encoding="utf-8") as f:
                    cfg = json.load(f)
            except Exception:
                cfg = {}
            chunk_ms = int(cfg.get("chunk_duration_ms", 250))

            self.matcher = AudioMatcher(
                resource_dir(),
                score_threshold=float(cfg.get("match_threshold", 0.40)),
                margin_threshold=float(cfg.get("min_margin", 0.20)),
                cooldown=float(cfg.get("cooldown_ms", 2000)) / 1000.0)
            self.capture = self._make_capture(self.selected_source,
                                              chunk_ms)
            self.capture.start()
            # 抗环境音：用采集采样率 + 随程序提供的农场/山谷环境样本预置噪声谱
            self.guard = AudioGuard(
                self.settings.all(),
                sample_rate=self.capture.samplerate,
                env_dir=resource_path("env"))

            self.is_listening = True
            self.paused = False
            self.buffer = deque(maxlen=max(4,
                                int(2.0 * 1000 / chunk_ms)))
            self._prev_rms = 0.0
            self.last_trigger = 0.0

            if self.overlay is None:
                self.overlay = OverlayWindow(self)
                self.security.register_window(self.overlay.win)
                self._apply_window_protection()
            else:
                self.overlay.redraw()
            self.overlay.show_wait()
            self.overlay.show()

            self.match_thread = threading.Thread(target=self.match_loop,
                                                 daemon=True)
            self.match_thread.start()
            self._sync_listen_ui()
            self._log(self.tr("log_started",
                              dev=self.capture.device_name,
                              n=self.matcher.template_count), "ok")
        except Exception as e:
            traceback.print_exc()
            self._log(self.tr("log_start_fail", e=e), "err")
            try:
                if self.capture:
                    self.capture.stop()
            except Exception:
                pass
            self.capture = None
            self.matcher = None

    def _make_capture(self, source, chunk_ms):
        from audio_capture import AudioCapture
        return AudioCapture(source, chunk_ms=chunk_ms,
                            on_error=lambda m: self.ui_q.put(
                                ("log", self.tr("log_capture_err",
                                                msg=m), "err"))
                            if m else None)

    def stop_listening(self):
        if not self.is_listening:
            return
        self.is_listening = False
        self.paused = False
        try:
            if self.capture:
                self.capture.stop()
        except Exception as e:
            self._log("stop error: %s" % e, "err")
        if self.overlay:
            self.overlay.hide()
        self.capture = None
        self.matcher = None
        self._sync_listen_ui()
        self._log(self.tr("log_stopped"), "info")

    def _sync_listen_ui(self):
        if hasattr(self, "btn_toggle"):
            self.btn_toggle.configure(
                text=self.tr("home_stop") if self.is_listening
                else self.tr("home_start"),
                style="Accent.TButton")

    # ================================================================
    # 识别线程
    # ================================================================
    def match_loop(self):
        while self.is_listening:
            chunk = self.capture.get_audio_chunk(0.3)
            if chunk is None:
                time.sleep(0.01)
                continue
            self._last_level = float(np.sqrt((chunk ** 2).mean() + 1e-12))
            if self.paused:
                continue
            g = self.guard.process(chunk)
            rms = float(np.sqrt((g ** 2).mean() + 1e-12))
            # 音效起点（安静→有声跳变）：丢弃此前的静音，从音效起点集中开窗，
            # 短音效才不会被满窗静音稀释、导致得分偏低
            if rms >= self.trigger_level and \
                    self._prev_rms < self.trigger_level:
                self.buffer.clear()
            self.buffer.append(g)
            self._prev_rms = rms
            if len(self.buffer) < 2:
                continue
            if rms < self.trigger_level:
                continue
            audio = np.concatenate(self.buffer)
            try:
                result = self.matcher.match(audio,
                                           self.capture.samplerate)
            except Exception as e:
                self.ui_q.put(("log", "match error: %s" % e, "err"))
                result = None
            if not result:
                continue
            now = time.time()
            # 仅防同一轮窗口的瞬时重复；跨音效的去重已由 matcher 按 name 冷却
            if now - self.last_trigger < 0.6:
                continue
            self.last_trigger = now
            self.ui_q.put(("result", result))
            # 识别后重置窗口：下一个音效在干净窗口识别，避免被本次音效残留压低分数
            self.buffer.clear()

    # ================================================================
    # 日志 / 异常
    # ================================================================
    def _log(self, text, tag="info"):
        self.ui_q.put(("log", text, tag))

    def _append_log(self, text, tag):
        if not hasattr(self, "log_widget"):
            return
        w = self.log_widget
        w.configure(state="normal")
        w.insert("end", "[%s] %s\n" % (now_str(), text), tag)
        if int(w.index("end-1c").split(".")[0]) > 400:
            w.delete("1.0", "100.0")
        w.see("end")
        w.configure(state="disabled")

    def _sys_hook(self, et, ev, tb):
        self._log("未捕获异常:\n" + "".join(
            traceback.format_exception(et, ev, tb)), "err")

    def _tk_hook(self, et, ev, tb):
        self._log("界面回调异常:\n" + "".join(
            traceback.format_exception(et, ev, tb)), "err")

    # ================================================================
    # 主轮询
    # ================================================================
    def poll(self):
        # UI 队列
        try:
            while True:
                item = self.ui_q.get_nowait()
                if item[0] == "toggle":
                    self.toggle_listening()
                elif item[0] == "toggle_guard":
                    self.toggle_guard()
                elif item[0] == "result":
                    self._handle_result(item[1])
                elif item[0] == "log":
                    self._append_log(item[1], item[2])
        except queue.Empty:
            pass

        self._update_status()
        self._draw_level()
        self.root.after(80, self.poll)

    def _handle_result(self, result):
        entry = entry_for_wav(result["file"])
        if entry is None:
            return
        if self.overlay:
            self.overlay.show_result(entry)
        if entry["kind"] == "single":
            name = self.i18n.item(entry["item"])
        else:
            name = self.i18n.group(entry["group"])
        self._append_log(self.tr(
            "log_recognized", name=name, file=result["file"],
            s="%.2f" % result["score"],
            m="%.2f" % result["margin"]), "ok")

    def _update_status(self):
        if self.is_listening and self.capture:
            txt = self.tr("status_listening",
                          dev=self.capture.device_name,
                          sr=self.capture.samplerate,
                          n=self.matcher.template_count)
        else:
            txt = self.tr("status_idle")
        if self.status_var.get() != txt:
            self.status_var.set(txt)

    def _draw_level(self):
        cv = getattr(self, "level_canvas", None)
        if cv is None:
            return
        cv.delete("all")
        w = cv.winfo_width() - 4
        lvl = self._last_level if self.is_listening else 0.0
        bw = max(2, int(w * min(1.0, lvl / 0.1)))
        cv.create_rectangle(2, 3, 2 + bw, 13,
                            fill=self.theme["green"], outline="")
        gx = 2 + int(w * min(1.0, self.trigger_level / 0.1))
        cv.create_line(gx, 2, gx, 14, fill=self.theme["red"], width=2)
        cv.create_text(w - 2, 8, anchor="e", text="%.3f" % lvl,
                       fill=self.theme["fg_dim"],
                       font=("Consolas", 7))

    # ================================================================
    def on_close(self):
        self.is_listening = False
        try:
            if self.capture:
                self.capture.stop()
            self.global_hotkey.stop()
            self.guard_hotkey.stop()
            self.security.shutdown()
        except Exception:
            pass
        self.root.destroy()


def main():
    if "--selftest" in sys.argv:
        import traceback
        import app_paths
        udir = app_paths.user_data_dir()
        os.makedirs(udir, exist_ok=True)
        report = os.path.join(udir, "BETA_selftest_report.txt")
        ok = False
        try:
            import beta_selftest
            ok = beta_selftest.run(report)
        except Exception:
            with open(report, "w", encoding="utf-8") as f:
                f.write("FATAL during self-test:\n" + traceback.format_exc())
        # 尽力再复制一份到 exe 同目录
        if getattr(sys, "frozen", False):
            try:
                alt = os.path.join(os.path.dirname(sys.executable),
                                   "BETA_selftest_report.txt")
                with open(report, "r", encoding="utf-8") as a, \
                        open(alt, "w", encoding="utf-8") as b:
                    b.write(a.read())
            except Exception:
                pass
        sys.exit(0 if ok else 1)
    app = App()
    app.root.mainloop()


if __name__ == "__main__":
    main()
