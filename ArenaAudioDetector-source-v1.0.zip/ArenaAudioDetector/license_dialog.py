# -*- coding: utf-8 -*-
"""
license_dialog.py —— 首次启动用户协议同意弹窗（模态 · 置顶）
================================================================
未在设置中记录 license_agreed 时弹出：
  - 滚动显示 EULA.md 全文；
  - 必须勾选“我已阅读并同意遵守”，“同意”按钮才可用；
  - 同意 -> 记录 license_agreed=True 并进入主界面；
  - 拒绝 -> 退出程序。
采用 overrideredirect + topmost（与识别浮窗同级），可稳定浮于全屏游戏之前。
"""

import tkinter as tk
from tkinter import ttk

from app_paths import resource_path


class LicenseDialog:
    def __init__(self, app):
        self.app = app
        self.accepted = False
        t = app.theme

        self.win = tk.Toplevel(app.root)
        self.win.overrideredirect(True)
        self.win.attributes("-topmost", True)
        self.win.configure(bg=t["bg"])

        w, h = 760, 600
        sw = self.win.winfo_screenwidth()
        sh = self.win.winfo_screenheight()
        self.win.geometry("%dx%d+%d+%d" % (w, h, (sw - w) // 2,
                                           (sh - h) // 2))

        # 自定义标题条
        bar = tk.Frame(self.win, bg=t["bg2"])
        bar.pack(fill="x")
        tk.Label(bar, text=app.tr("license_title"), bg=t["bg2"],
                 fg=t["gold"], font=("Segoe UI", 11, "bold")).pack(
            side="left", padx=12, pady=8)

        # 协议正文（滚动）
        body = ttk.Frame(self.win, padding=12)
        body.pack(fill="both", expand=True)
        txt = tk.Text(body, wrap="word", relief="flat",
                      font=("Segoe UI", 10), padx=8, pady=8,
                      bg=t["bg2"], fg=t["fg"])
        lsb = ttk.Scrollbar(body, orient="vertical", command=txt.yview)
        txt.configure(yscrollcommand=lsb.set)
        lsb.pack(side="right", fill="y")
        txt.pack(side="left", fill="both", expand=True)
        try:
            with open(resource_path("EULA.md"), "r", encoding="utf-8") as f:
                txt.insert("1.0", f.read())
        except Exception:
            txt.insert("1.0", app.tr("license_missing"))
        txt.configure(state="disabled")

        # 勾选 + 按钮
        foot = ttk.Frame(self.win, padding=(12, 0, 12, 12))
        foot.pack(fill="x")
        self.var = tk.BooleanVar(value=False)
        ttk.Checkbutton(foot, text=app.tr("license_check"),
                        variable=self.var,
                        command=self._toggle).pack(anchor="w")

        brow = ttk.Frame(foot)
        brow.pack(fill="x", pady=(8, 0))
        self.btn_ok = ttk.Button(brow, text=app.tr("license_accept"),
                                 style="Accent.TButton", state="disabled",
                                 command=self._accept)
        self.btn_ok.pack(side="right")
        ttk.Button(brow, text=app.tr("license_decline"),
                   command=self._decline).pack(side="right", padx=8)

        # 模态（窗口构建完成后）
        self.win.grab_set()

    def _toggle(self):
        self.btn_ok.config(state="normal" if self.var.get() else "disabled")

    def _accept(self):
        if not self.var.get():
            return
        self.accepted = True
        self.app.set_setting("license_agreed", True)
        self.win.destroy()

    def _decline(self):
        self.accepted = False
        self.win.destroy()
