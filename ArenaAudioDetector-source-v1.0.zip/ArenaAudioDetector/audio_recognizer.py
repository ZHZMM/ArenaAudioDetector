# -*- coding: utf-8 -*-
"""
ArenaAudioDetector —— 10 段游戏音效的精准识别算法
=================================================
原理：
  1. 指纹提取（特征）：
     - 统一重采样到 22050 Hz、转单声道、预加重；
     - 1024 点 FFT、256 点步进（约 11.6ms/帧），对数间隔频带（约 144 个）；
     - 每个频带在时间轴上做 z-score 标准化（对音量/房间混响鲁棒）；
     - 在全部模板帧上学习 PCA 白化变换：把各模板共有的成分压下去、
       把彼此不同的成分放大 —— 这是让 10 段相似音效“可分”的关键。
  2. 识别匹配：
     - 对每段模板做上述指纹；待识别音频提取同样的指纹；
     - 计算两段指纹逐帧余弦相似度矩阵，沿对角线滑动对齐（容忍起始偏移），
       只统计双方有效（非静音）帧，取平均相似度最大值为匹配得分；
     - 得分最高者为识别结果，同时给出与第二名的差值（区分度），
       得分与区分度同时达标才判定“命中”。

用法：
  python audio_recognizer.py info
  python audio_recognizer.py recognize 某文件.wav
  python audio_recognizer.py listen [--device N]
  python audio_recognizer.py selftest [--noise-db 18]
依赖：numpy、sounddevice（仅 listen 模式需要 sounddevice）
"""

import os
import sys
import wave
import time
import argparse
import glob

import numpy as np

# 可修改的默认参数 -----------------------------------------------------------
# 模板目录：源码运行=脚本所在目录；PyInstaller 打包=解压目录 _MEIPASS
if getattr(sys, "frozen", False):
    DEFAULT_DIR = getattr(sys, "_MEIPASS",
                          os.path.dirname(os.path.abspath(__file__)))
else:
    DEFAULT_DIR = os.path.dirname(os.path.abspath(__file__))
TARGET_SR = 22050          # 统一分析采样率
N_FFT = 1024               # FFT 窗长
HOP = 256                  # 帧步进（约 11.6 ms/帧 @22050Hz）
N_BANDS = 256              # 请求的对数频带数（去重后实际约 144 个频带）
F_MIN = 50.0               # 最低频带
ACCEPT_SCORE = 0.40        # 判定为“命中”的最低得分（陌生声音实测 ≤0.18，已知声音即使加12dB噪声也 ≥0.46）
MIN_MARGIN = 0.20          # 命中要求：与第二名的得分差至少这么多
# ---------------------------------------------------------------------------

# ----------------------------- 基础工具 -------------------------------------

def _log_band_edges(n_fft, n_bands):
    """对数间隔频带边界（覆盖 1 ~ n_fft/2+1 的 FFT bin）"""
    n_full = n_fft // 2 + 1
    edges = np.linspace(0, np.log2(n_full), n_bands + 1)
    edges = np.unique(np.round(2 ** edges).astype(int))
    edges = np.clip(edges, 1, n_full)
    return edges


def load_wav(path, target_sr=TARGET_SR):
    """读取 WAV -> (单声道 float32 波形, 采样率)"""
    with wave.open(path, "rb") as w:
        sr = w.getframerate()
        ch = w.getnchannels()
        sw = w.getsampwidth()
        n = w.getnframes()
        raw = w.readframes(n)
    dtype = {1: np.int8, 2: np.int16, 4: np.int32}[sw]
    x = np.frombuffer(raw, dtype=dtype).astype(np.float64)
    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)
    scale = {1: 128.0, 2: 32768.0, 4: 2147483648.0}[sw]
    x = x / scale
    if sr != target_sr:
        x = _resample_linear(x, sr, target_sr)
    return x.astype(np.float32), target_sr


def _resample_linear(x, sr_old, sr_new):
    n_out = int(round(len(x) * sr_new / sr_old))
    t_new = np.linspace(0, len(x) - 1, n_out)
    return np.interp(t_new, np.arange(len(x)), x)


def fingerprint(y, sr=TARGET_SR):
    """
    提取对数频谱指纹（原始特征，未白化）。
    返回: feat (n_frames, D) 按频带 z-score；rms (n_frames,)
    """
    if len(y) < N_FFT:
        y = np.pad(y, (0, N_FFT - len(y)))
    # 预加重：突出高频细节，压低低频噪声
    y = np.concatenate(([y[0]], y[1:] - 0.97 * y[:-1]))

    n_frames = 1 + (len(y) - N_FFT) // HOP
    idx = np.arange(N_FFT)[None, :] + HOP * np.arange(n_frames)[:, None]
    frames = y[idx]
    win = np.hanning(N_FFT)
    spec = np.abs(np.fft.rfft(frames * win, n=N_FFT, axis=1)) ** 2

    edges = _log_band_edges(N_FFT, N_BANDS)
    n_b = len(edges) - 1
    bands = np.zeros((n_frames, n_b))
    for k in range(n_b):
        bands[:, k] = spec[:, edges[k]:edges[k + 1]].mean(axis=1)
    logb = np.log(bands + 1e-6)

    mu = logb.mean(axis=0)
    sd = logb.std(axis=0) + 1e-6
    feat = np.clip((logb - mu) / sd, -5.0, 5.0)

    rms = np.sqrt((frames ** 2).mean(axis=1) + 1e-12)
    return feat.astype(np.float32), rms.astype(np.float32)


# ------------------------- PCA 白化 ----------------------------------------

def fit_whiten(feats, reg=1e-3, keep_min=1e-4):
    """
    在全部模板帧上学习 PCA 白化变换。
    返回 (mu, T)：白化后的特征 = (X - mu) @ T
    """
    X = np.vstack(feats)
    mu = X.mean(axis=0)
    Xc = X - mu
    cov = (Xc.T @ Xc) / len(X)
    evals, evecs = np.linalg.eigh(cov)
    order = np.argsort(evals)[::-1]
    evals, evecs = evals[order], evecs[:, order]
    keep = evals > evals[0] * keep_min
    if keep.sum() < 4:
        keep[:8] = True
    evals, evecs = evals[keep], evecs[:, keep]
    T = evecs @ np.diag(1.0 / np.sqrt(evals + reg))
    return mu.astype(np.float32), T.astype(np.float32)


# --------------------------- 模板指纹库 --------------------------------------

class FingerprintDB:
    """模板指纹库：目录中每个 wav 对应一个白化后的指纹"""

    def __init__(self, directory=DEFAULT_DIR):
        self.directory = os.path.abspath(directory)
        self.names = []
        self.paths = []
        self.feats = []          # 白化后的指纹
        self.rmses = []
        self.raw_dims = 0
        self.whiten_dims = 0
        self.durations = []
        self.max_dur = 0.0
        self._build()

    def _build(self):
        files = sorted(glob.glob(os.path.join(self.directory, "*.wav")))
        if not files:
            raise FileNotFoundError(f"目录中没有 wav 文件: {self.directory}")
        raws, rmses = [], []
        for f in files:
            y, sr = load_wav(f)
            feat, rms = fingerprint(y, sr)
            raws.append(feat)
            rmses.append(rms)
            self.names.append(os.path.basename(f))
            self.paths.append(f)
            self.durations.append(len(y) / sr)
            self.max_dur = max(self.max_dur, len(y) / sr)
        self.raw_dims = raws[0].shape[1]
        mu, T = fit_whiten(raws)
        self._whiten = (mu, T)
        self.feats = [(f - mu) @ T for f in raws]
        self.whiten_dims = T.shape[1]
        self.rmses = rmses

    def whiten(self, feat):
        """对查询音频的原始特征做同样的白化变换"""
        mu, T = self._whiten
        return (feat - mu) @ T

    def info(self):
        lines = [f"指纹库: {self.directory}（{len(self.names)} 个模板）",
                 f"特征维度: {self.raw_dims} -> PCA白化 {self.whiten_dims}",
                 f"{'模板':<14}{'时长/s':>8}  帧数"]
        for n, d, ft in zip(self.names, self.durations, self.feats):
            lines.append(f"{n:<14}{d:8.3f}  {len(ft):4d}")
        return "\n".join(lines)


# ------------------------------ 匹配算法 -------------------------------------

def match_score(q_feat, q_rms, t_feat, t_rms):
    """
    查询指纹与单个模板的匹配得分（0~1，越大越像）。
    滑动对角线对齐（容忍起始偏移），只统计双方有效帧，取平均余弦最大值为得分。
    返回: (best_score, best_offset_frames)
    """
    qn = q_feat / (np.linalg.norm(q_feat, axis=1, keepdims=True) + 1e-8)
    tn = t_feat / (np.linalg.norm(t_feat, axis=1, keepdims=True) + 1e-8)
    S = qn @ tn.T
    nq, nt = S.shape

    t_act = t_rms > t_rms.max() * 0.03
    if t_act.sum() < 2:
        t_act[:] = True
    q_peak = q_rms.max()

    best, best_d = -2.0, 0
    for d in range(-(nt - 1), nq):
        i0, j0 = max(d, 0), max(-d, 0)
        ln = min(nq - i0, nt - j0)
        if ln < 2:
            continue
        diag = np.diag(S[i0:i0 + ln, j0:j0 + ln])
        mask = t_act[j0:j0 + ln] & (q_rms[i0:i0 + ln] > q_peak * 0.02)
        if mask.sum() < 2:
            continue
        sc = float(diag[mask].mean())
        if sc > best:
            best, best_d = sc, d
    return best, best_d


def recognize_audio(y, sr, db, return_all=False):
    """对一段音频波形识别。返回 (name, score, second, margin) 或 dict"""
    q_raw, q_rms = fingerprint(y, sr)
    q_feat = db.whiten(q_raw)
    results = []
    for name, t_feat, t_rms in zip(db.names, db.feats, db.rmses):
        sc, off = match_score(q_feat, q_rms, t_feat, t_rms)
        results.append((sc, name, off))
    results.sort(key=lambda r: -r[0])
    best_sc, best_name, best_off = results[0]
    second_sc = results[1][0] if len(results) > 1 else -1.0
    margin = best_sc - second_sc
    if return_all:
        return {"best": best_name, "score": best_sc, "second": second_sc,
                "margin": margin, "offset_frames": best_off,
                "scores": {n: s for s, n, _ in results}}
    return best_name, best_sc, second_sc, margin


def recognize_file(path, db):
    y, sr = load_wav(path)
    return recognize_audio(y, sr, db, return_all=True)


# ----------------------------- 实时监听 --------------------------------------

def listen(db, device=None, block=1024, threshold=0.015):
    """麦克风实时监听：播放这 10 段音频中任意一段即自动识别"""
    import sounddevice as sd

    sr = int(sd.query_devices(device, "input").get("default_samplerate", 44100))
    max_len = int((db.max_dur + 1.5) * sr)
    print(f"开始监听（采样率 {sr} Hz，输入设备 {device or '默认'}）。"
          f"播放 {db.directory} 中的音频即可识别，Ctrl+C 退出。\n")

    rms_hist = []
    state = "idle"
    buf = []

    def _rms(x):
        return float(np.sqrt((x ** 2).mean() + 1e-12))

    try:
        # 阻塞式 InputStream（不传 callback，才能用 stream.read 读取）
        with sd.InputStream(samplerate=sr, device=device, channels=1,
                            blocksize=block, dtype="float32") as stream:
            while True:
                data, _ = stream.read(block)
                data = data[:, 0]
                r = _rms(data)

                if state == "idle":
                    rms_hist.append(r)
                    if len(rms_hist) > 50:
                        rms_hist.pop(0)
                    floor = float(np.percentile(rms_hist[-25:], 50)) * 4.0
                    if r > max(floor, threshold):
                        state = "recording"
                        buf = [data.copy()]
                        print("检测到声音事件，录制中…", end="", flush=True)
                else:
                    buf.append(data.copy())
                    if len(buf) * block >= max_len:
                        print("（达到最长时长）", end="")
                        _finish(db, buf, sr)
                        buf, state = [], "idle"
                        time.sleep(0.5)
                        continue
                    tail = np.concatenate(buf[-8:]) if len(buf) >= 8 else np.concatenate(buf)
                    if _rms(tail) < threshold * 0.6:
                        _finish(db, buf, sr)
                        buf, state = [], "idle"
                        time.sleep(0.6)
    except KeyboardInterrupt:
        print("\n已停止监听。")


def _trim_silence(y, sr, th=0.02):
    n = len(y)
    step = int(0.01 * sr)
    rms = np.array([np.sqrt(np.mean(y[i:i + step] ** 2) + 1e-12)
                    for i in range(0, n, step)])
    peak = rms.max()
    if peak <= 1e-6:
        return y
    act = rms > peak * th
    if not act.any():
        return y
    a, b = np.argmax(act), len(act) - 1 - np.argmax(act[::-1])
    return y[a * step:min((b + 1) * step, n)]


def _finish(db, buf, sr):
    y = np.concatenate(buf)
    y = _trim_silence(y, sr)
    if len(y) < sr * 0.05:
        print("（过短，忽略）")
        return
    res = recognize_audio(y, sr, db, return_all=True)
    if res["score"] >= ACCEPT_SCORE and res["margin"] >= MIN_MARGIN:
        print(f"\n✅ 识别结果：{res['best']}  （得分 {res['score']:.3f}，"
              f"第二名 {res['second']:.3f}，区分度 {res['margin']:.3f}）")
    else:
        print(f"\n❓ 未识别（最接近 {res['best']}，得分 {res['score']:.3f}，"
              f"区分度 {res['margin']:.3f} 低于阈值）")


# ------------------------------- 自测 ---------------------------------------

def selftest(db, noise_db=18.0):
    print("=" * 74)
    print(f"自测 1：原文件自匹配")
    print("=" * 74)
    ok = True
    for name, path in zip(db.names, db.paths):
        y, sr = load_wav(path)
        res = recognize_audio(y, sr, db, return_all=True)
        hit = res["best"] == name and res["score"] >= ACCEPT_SCORE
        ok &= hit
        print(f"{name:<14} -> 识别为 {res['best']:<14} 得分 {res['score']:.3f} "
              f"区分度 {res['margin']:.3f}  {'✓' if hit else '✗'}")

    print("\n" + "=" * 74)
    print(f"自测 2：抗干扰（+0.3s 前导静音 + 音量×0.4 + {noise_db}dB 白噪声）")
    print("=" * 74)
    rng = np.random.default_rng(42)
    ok2 = True
    for name, path in zip(db.names, db.paths):
        y, sr = load_wav(path)
        y2 = np.concatenate([np.zeros(int(0.3 * sr), np.float32), y * 0.4])
        noise = rng.standard_normal(len(y2)).astype(np.float32)
        sig_p = float(np.sqrt((y2 ** 2).mean()))
        y2 = y2 + noise * (sig_p / (10 ** (noise_db / 20)))
        res = recognize_audio(y2, sr, db, return_all=True)
        hit = res["best"] == name
        ok2 &= hit
        print(f"{name:<14} -> 识别为 {res['best']:<14} 得分 {res['score']:.3f} "
              f"区分度 {res['margin']:.3f}  {'✓' if hit else '✗'}")

    print("\n" + "=" * 74)
    print("自测 3：模板间最大相似度矩阵（对角线=自身，应显著高于其他）")
    print("=" * 74)
    n = len(db.names)
    M = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            M[i, j], _ = match_score(db.feats[i], db.rmses[i],
                                     db.feats[j], db.rmses[j])
    hdr = "".join(f"{x[:8]:>9}" for x in db.names)
    print(f"{'模板':<14}{hdr}   自身-最大他者")
    all_ok = True
    for i in range(n):
        row = "".join(f"{M[i, j]:9.3f}" for j in range(n))
        others = [M[i, j] for j in range(n) if j != i]
        margin = M[i, i] - (max(others) if others else -2)
        flag = "✓" if margin > MIN_MARGIN else "✗"
        all_ok &= margin > MIN_MARGIN
        print(f"{db.names[i]:<14}{row}   {margin:6.3f} {flag}")

    print("\n" + "=" * 74)
    print(f"结论：自匹配 {'全部通过 ✓' if ok else '存在失败 ✗'}；"
          f"抗干扰({noise_db}dB) {'全部通过 ✓' if ok2 else '存在失败 ✗'}；"
          f"两两可分 {'全部通过 ✓' if all_ok else '存在不可分 ✗'}")
    print("=" * 74)


# ------------------------------- 入口 ---------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description="ArenaAudioDetector：10 段音频精准识别（文件识别 / 麦克风实时监听）")
    ap.add_argument("mode", nargs="?", default="listen",
                    choices=["info", "recognize", "listen", "selftest"],
                    help="info=查看指纹库 | recognize=识别文件 | listen=麦克风监听 | selftest=自测")
    ap.add_argument("path", nargs="?", help="recognize 模式下要识别的 wav 文件")
    ap.add_argument("--dir", default=DEFAULT_DIR, help="模板音频所在目录")
    ap.add_argument("--device", default=None, type=int, help="麦克风设备编号（listen 模式）")
    ap.add_argument("--noise-db", default=18.0, type=float, help="selftest 抗干扰噪声强度(dB)")
    ap.add_argument("--list-devices", action="store_true", help="列出音频设备")
    args = ap.parse_args()

    if args.list_devices:
        try:
            import sounddevice as sd
            print(sd.query_devices())
        except Exception as e:
            print("无法枚举设备:", e)
        return

    db = FingerprintDB(args.dir)

    if args.mode == "info":
        print(db.info())
    elif args.mode == "recognize":
        if not args.path:
            print("请指定要识别的 wav 文件，例如：python audio_recognizer.py recognize test.wav")
            return
        y, sr = load_wav(args.path)
        res = recognize_audio(y, sr, db, return_all=True)
        print(f"待识别文件: {args.path}（{len(y) / sr:.3f}s）")
        print(f"\n识别结果: {res['best']}")
        print(f"匹配得分: {res['score']:.3f}   第二名: {res['second']:.3f}   区分度: {res['margin']:.3f}")
        hit = res["score"] >= ACCEPT_SCORE and res["margin"] >= MIN_MARGIN
        print("判定: " + ("命中 ✓" if hit else "未命中 ✗"))
        if args.path and os.path.abspath(args.path) in db.paths:
            pass
    elif args.mode == "selftest":
        print(db.info(), "\n")
        selftest(db, noise_db=args.noise_db)
    else:  # listen
        print(db.info(), "\n")
        listen(db, device=args.device)


if __name__ == "__main__":
    main()
