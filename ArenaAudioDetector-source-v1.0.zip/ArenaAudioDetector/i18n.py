# -*- coding: utf-8 -*-
"""
i18n.py —— 多语言框架（中文 / English / 日本語 / Русский）
================================================================
- 启动时检测 Windows 系统 UI 语言决定第一语言；
- 检测失败或不在支持列表时，默认英文（en）；
- 用户可在“设置”中手动覆盖。
物品名（约 50 个）与 UI 字符串均提供四种语言；日/俄为 BETA 翻译，可后续微调。
"""

import ctypes

LANGS = (
    ("zh", "中文"),
    ("en", "English"),
    ("ja", "日本語"),
    ("ru", "Русский"),
)
DEFAULT_LANG = "en"


# --------------------------------------------------------------------------
# 系统语言检测
# --------------------------------------------------------------------------

def detect_system_language():
    # Windows GetUserDefaultUILanguage -> 主语言 ID（低 8 位）
    try:
        lcid = ctypes.windll.kernel32.GetUserDefaultUILanguage()
        prim = lcid & 0xFF
        table = {0x04: "zh", 0x09: "en", 0x11: "ja", 0x19: "ru"}
        if prim in table:
            return table[prim]
    except Exception:
        pass
    # 兜底：Python locale
    try:
        import locale
        loc = (locale.getdefaultlocale()[0] or "").lower()
        for pre, code in (("zh", "zh"), ("ja", "ja"), ("ru", "ru"), ("en", "en")):
            if loc.startswith(pre):
                return code
    except Exception:
        pass
    return DEFAULT_LANG


# --------------------------------------------------------------------------
# UI 字符串
# --------------------------------------------------------------------------

STR = {
"zh": {
 "app_title": "暗区大金音效识别",
 "version_tag": "v1.0",
 "nav_home": "主页", "nav_settings": "设置", "nav_about": "关于",
 "home_listen_setup": "监听设置",
 "home_device": "监听设备：", "home_refresh": "刷新",
 "home_device_hint": "环回 = 直接抓取播放设备的系统声音（默认推荐，无需任何配置）；麦克风 = 拾取环境声；某个源打不开就换一个",
 "home_sensitivity": "监听灵敏度：",
 "home_sens_value": "数值 {v}（触发音量 {r}）",
 "home_sens_hint": "越高越能捕捉小声的大金音（适合系统音量低时）；游戏声音太吵导致误报就调低",
 "home_start": "▶ 开始监听", "home_stop": "■ 停止监听",
 "home_log": "日志 / 报错",
 "tab_listen": "监听", "tab_namelist": "大金清单",
 "status_idle": "状态：未监听",
 "status_listening": "状态：监听中 | {dev} | {sr}Hz | 模板 {n} 个",
 "ov_title": "🎧 大金识别", "ov_wait": "🎧 等待大金音效…",
 "nl_group": "组别", "nl_item": "物品", "nl_rarity": "品质",
 "nl_red": "红金", "nl_gold": "金", "nl_purple": "紫",
 "nl_g1": "第一组（可单件识别）",
 "s_general": "通用",
 "s_language": "界面语言", "s_language_auto": "首次启动：跟随系统（{lang}）",
 "s_theme": "主题", "s_theme_light": "浅色", "s_theme_dark": "深色",
 "s_theme_auto": "按系统时间自动切换",
 "s_theme_time": "深色时段（24小时制，例 19:00–07:00）",
 "s_audio": "音频",
 "s_hotkey": "开始 / 停止监听快捷键",
 "s_hotkey_enable": "启用全局快捷键",
 "s_hotkey_capture": "点击此处后按下组合键",
 "s_guard": "抗环境音（农场 / 山谷）",
 "s_guard_enable": "启用抗环境音预处理",
 "s_guard_gate": "噪声门（抑制持续底噪）",
 "s_guard_spectral": "环境噪声谱减（农场 / 山谷）",
 "s_guard_note": "以上为 BETA 准备能力，默认关闭，开启后请留意识别效果",
 "s_guard_hotkey_enable": "启用抗干扰 开/关 快捷键",
 "home_guard": "抗干扰",
 "home_guard_on": "抗干扰：开",
 "guard_on": "抗环境音已开启（农场 / 山谷）",
 "guard_off": "抗环境音已关闭",
 "license_title": "用户协议与免责声明",
 "license_check": "我已阅读并同意遵守本协议",
 "license_accept": "同意并进入",
 "license_decline": "不同意，退出",
 "license_missing": "未找到协议文件，请从发行包获取 EULA.md。",
 "s_security": "隐私与安全",
 "s_capture_protect": "窗口防屏幕捕获 / 录屏（WDA_EXCLUDEFROMCAPTURE）",
 "s_protected_procs": "受保护进程：检测到其运行时自动隐藏本软件",
 "s_proc_action": "检测到受保护进程时",
 "s_act_capture": "保持显示但禁止被捕获（推荐）",
 "s_act_overlay": "仅隐藏识别浮窗",
 "s_act_all": "隐藏全部窗口",
 "s_act_pause": "暂停监听",
 "s_add_proc": "添加",
 "s_remove": "移除", "s_reset": "恢复默认",
 "s_saved": "设置已自动保存",
 "about_title": "关于",
 "about_desc": "《暗区突围：无限》大金音效实时识别工具",
 "about_dev": "开发者", "about_github": "GitHub", "about_author": "ND 著",
 "about_disclaimer": "仅在本机采集分析音频，不修改游戏进程，无封号风险。仅供个人学习与技术研究。",
 "log_devices_found": "已检测到 {n} 个可用音频源",
 "log_no_device": "⚠️ 未找到可用音频源",
 "log_started": "🎧 监听已启动：{dev}，模板 {n} 个",
 "log_stopped": "■ 监听已停止",
 "log_start_fail": "启动监听失败: {e}",
 "log_recognized": "🎯 识别: {name}（{file}，得分 {s}，区分度 {m}）",
 "log_capture_err": "采集错误：{msg}",
 "log_select_source": "请先选择有效的音频源",
 "hk_registered": "全局快捷键已注册：{hk}",
 "hk_failed": "全局快捷键注册失败：{hk}（可能被占用）",
 "protected_hide": "检测到受保护进程，已隐藏窗口",
 "protected_show": "受保护进程已退出，窗口恢复",
},
"en": {
 "app_title": "Arena Gold Audio Detector",
 "version_tag": "v1.0",
 "nav_home": "Home", "nav_settings": "Settings", "nav_about": "About",
 "home_listen_setup": "Listening Setup",
 "home_device": "Audio source:", "home_refresh": "Refresh",
 "home_device_hint": "Loopback = capture the system audio of a playback device directly (recommended, no setup needed); Microphone = ambient sound; if a source fails, pick another",
 "home_sensitivity": "Sensitivity:",
 "home_sens_value": "Value {v} (trigger level {r})",
 "home_sens_hint": "Higher catches quiet gold sounds (good at low system volume); lower it if loud game audio causes false alerts",
 "home_start": "▶ Start", "home_stop": "■ Stop",
 "home_log": "Log / Errors",
 "tab_listen": "Listen", "tab_namelist": "Gold List",
 "status_idle": "Status: idle",
 "status_listening": "Status: listening | {dev} | {sr}Hz | {n} templates",
 "ov_title": "🎧 Gold Detect", "ov_wait": "🎧 Waiting for gold sound…",
 "nl_group": "Group", "nl_item": "Item", "nl_rarity": "Rarity",
 "nl_red": "Red", "nl_gold": "Gold", "nl_purple": "Purple",
 "nl_g1": "Group 1 (single-item recognition)",
 "s_general": "General",
 "s_language": "Interface language", "s_language_auto": "First launch: follow system ({lang})",
 "s_theme": "Theme", "s_theme_light": "Light", "s_theme_dark": "Dark",
 "s_theme_auto": "Auto-switch by system time",
 "s_theme_time": "Dark period (24h, e.g. 19:00–07:00)",
 "s_audio": "Audio",
 "s_hotkey": "Start / Stop hotkey",
 "s_hotkey_enable": "Enable global hotkey",
 "s_hotkey_capture": "Click here, then press a key combo",
 "s_guard": "Ambient-noise guard (Farm / Valley)",
 "s_guard_enable": "Enable ambient-noise preprocessing",
 "s_guard_gate": "Noise gate (suppress constant background)",
 "s_guard_spectral": "Ambient spectral subtraction (Farm / Valley)",
 "s_guard_note": "BETA prepared capabilities, off by default; watch recognition when enabled",
 "s_guard_hotkey_enable": "Enable guard on/off hotkey",
 "home_guard": "Anti-Noise",
 "home_guard_on": "Anti-Noise: ON",
 "guard_on": "Ambient-noise guard enabled (Farm / Valley)",
 "guard_off": "Ambient-noise guard disabled",
 "license_title": "License Agreement & Disclaimer",
 "license_check": "I have read and agree to comply with this agreement",
 "license_accept": "Agree & Continue",
 "license_decline": "Decline & Exit",
 "license_missing": "Agreement file not found. Obtain EULA.md from the release.",
 "s_security": "Privacy & Security",
 "s_capture_protect": "Exclude windows from screen capture / recording",
 "s_protected_procs": "Protected processes: auto-hide this app while they run",
 "s_proc_action": "When a protected process is detected",
 "s_act_capture": "Keep visible but block capture (recommended)",
 "s_act_overlay": "Hide overlay only",
 "s_act_all": "Hide all windows",
 "s_act_pause": "Pause listening",
 "s_add_proc": "Add",
 "s_remove": "Remove", "s_reset": "Restore defaults",
 "s_saved": "Settings saved automatically",
 "about_title": "About",
 "about_desc": "Real-time gold-item sound detector for Arena Breakout: Infinite",
 "about_dev": "Developers", "about_github": "GitHub", "about_author": "by ND",
 "about_disclaimer": "Captures and analyzes audio locally; does not modify the game process, no ban risk. For personal study and research only.",
 "log_devices_found": "Found {n} available audio sources",
 "log_no_device": "⚠️ No available audio source",
 "log_started": "🎧 Listening started: {dev}, {n} templates",
 "log_stopped": "■ Listening stopped",
 "log_start_fail": "Failed to start: {e}",
 "log_recognized": "🎯 {name} ({file}, score {s}, margin {m})",
 "log_capture_err": "Capture error: {msg}",
 "log_select_source": "Please select a valid audio source",
 "hk_registered": "Global hotkey registered: {hk}",
 "hk_failed": "Failed to register hotkey: {hk} (may be in use)",
 "protected_hide": "Protected process detected, windows hidden",
 "protected_show": "Protected process exited, windows restored",
},
"ja": {
 "app_title": "アリーナ大金サウンド検出",
 "version_tag": "v1.0",
 "nav_home": "ホーム", "nav_settings": "設定", "nav_about": "情報",
 "home_listen_setup": "リスニング設定",
 "home_device": "オーディオソース：", "home_refresh": "更新",
 "home_device_hint": "ループバック＝再生デバイスのシステム音を直接取得（推奨・設定不要）；マイク＝周囲の音；開けないソースは別のものを選択",
 "home_sensitivity": "感度：",
 "home_sens_value": "値 {v}（トリガー音量 {r}）",
 "home_sens_hint": "高いほど小さな大金の音を捉えます（システム音量が低い時）；ゲーム音がうるさく誤検知する場合は下げてください",
 "home_start": "▶ 開始", "home_stop": "■ 停止",
 "home_log": "ログ / エラー",
 "tab_listen": "リスニング", "tab_namelist": "大金リスト",
 "status_idle": "ステータス：停止中",
 "status_listening": "ステータス：リスニング中 | {dev} | {sr}Hz | テンプレート {n} 個",
 "ov_title": "🎧 大金検出", "ov_wait": "🎧 大金の音を待機中…",
 "nl_group": "グループ", "nl_item": "アイテム", "nl_rarity": "レアリティ",
 "nl_red": "赤", "nl_gold": "金", "nl_purple": "紫",
 "nl_g1": "第1グループ（単品識別）",
 "s_general": "一般",
 "s_language": "表示言語", "s_language_auto": "初回起動：システムに追従（{lang}）",
 "s_theme": "テーマ", "s_theme_light": "ライト", "s_theme_dark": "ダーク",
 "s_theme_auto": "システム時刻で自動切替",
 "s_theme_time": "ダーク時間帯（24時間制、例 19:00–07:00）",
 "s_audio": "オーディオ",
 "s_hotkey": "開始 / 停止ホットキー",
 "s_hotkey_enable": "グローバルホットキーを有効化",
 "s_hotkey_capture": "ここをクリックしてキー組み合わせを押す",
 "s_guard": "環境音ガード（農場 / 山谷）",
 "s_guard_enable": "環境音前処理を有効化",
 "s_guard_gate": "ノイズゲート（持続的なノイズを抑制）",
 "s_guard_spectral": "環境ノイズスペクトル減算（農場 / 山谷）",
 "s_guard_note": "BETA準備機能、既定オフ。有効時は認識結果を確認してください",
 "s_guard_hotkey_enable": "ガード ON/OFF ホットキーを有効化",
 "home_guard": "アンチノイズ",
 "home_guard_on": "アンチノイズ：ON",
 "guard_on": "環境音ガードをオン（農場 / 山谷）",
 "guard_off": "環境音ガードをオフ",
 "license_title": "利用規約と免責事項",
 "license_check": "本規約を読み、遵守することに同意します",
 "license_accept": "同意して続行",
 "license_decline": "同意しない（終了）",
 "license_missing": "規約ファイルが見つかりません。配布パッケージから EULA.md を取得してください。",
 "s_security": "プライバシーとセキュリティ",
 "s_capture_protect": "画面キャプチャ / 録画からウィンドウを除外",
 "s_protected_procs": "保護プロセス：実行中は本ソフトを自動非表示",
 "s_proc_action": "保護プロセスを検出した時",
 "s_act_capture": "表示を維持しキャプチャをブロック（推奨）",
 "s_act_overlay": "オーバーレイのみ非表示",
 "s_act_all": "すべてのウィンドウを非表示",
 "s_act_pause": "リスニングを一時停止",
 "s_add_proc": "追加",
 "s_remove": "削除", "s_reset": "既定に戻す",
 "s_saved": "設定は自動保存されました",
 "about_title": "情報",
 "about_desc": "『Arena Breakout: Infinite』大金サウンド リアルタイム検出ツール",
 "about_dev": "開発者", "about_github": "GitHub", "about_author": "ND 著",
 "about_disclaimer": "音声はローカルでのみ取得・分析し、ゲームプロセスを変更しないためBANリスクはありません。個人の学習・研究のみ。",
 "log_devices_found": "利用可能なオーディオソース {n} 個を検出",
 "log_no_device": "⚠️ 利用可能なオーディオソースがありません",
 "log_started": "🎧 リスニング開始：{dev}、テンプレート {n} 個",
 "log_stopped": "■ リスニング停止",
 "log_start_fail": "開始に失敗: {e}",
 "log_recognized": "🎯 {name}（{file}、スコア {s}、マージン {m}）",
 "log_capture_err": "キャプチャエラー：{msg}",
 "log_select_source": "有効なオーディオソースを選択してください",
 "hk_registered": "グローバルホットキー登録：{hk}",
 "hk_failed": "ホットキー登録失敗：{hk}（使用中の可能性）",
 "protected_hide": "保護プロセスを検出、ウィンドウを非表示",
 "protected_show": "保護プロセス終了、ウィンドウ復帰",
},
"ru": {
 "app_title": "Определение звука золота Arena",
 "version_tag": "v1.0",
 "nav_home": "Главная", "nav_settings": "Настройки", "nav_about": "О программе",
 "home_listen_setup": "Настройки прослушивания",
 "home_device": "Источник звука:", "home_refresh": "Обновить",
 "home_device_hint": "Loopback — прямой захват системного звука устройства воспроизведения (рекомендуется, без настройки); микрофон — окружающий звук; если источник не открывается, выберите другой",
 "home_sensitivity": "Чувствительность:",
 "home_sens_value": "Значение {v} (порог {r})",
 "home_sens_hint": "Выше — ловит тихие звуки золота (при низкой громкости); снизьте, если громкий звук игры даёт ложные срабатывания",
 "home_start": "▶ Старт", "home_stop": "■ Стоп",
 "home_log": "Журнал / ошибки",
 "tab_listen": "Прослушивание", "tab_namelist": "Список золота",
 "status_idle": "Статус: не активно",
 "status_listening": "Статус: прослушивание | {dev} | {sr}Гц | шаблонов: {n}",
 "ov_title": "🎧 Детект золота", "ov_wait": "🎧 Ожидание звука золота…",
 "nl_group": "Группа", "nl_item": "Предмет", "nl_rarity": "Редкость",
 "nl_red": "Красный", "nl_gold": "Золото", "nl_purple": "Фиолет.",
 "nl_g1": "Группа 1 (распознавание предмета)",
 "s_general": "Общие",
 "s_language": "Язык интерфейса", "s_language_auto": "Первый запуск: как в системе ({lang})",
 "s_theme": "Тема", "s_theme_light": "Светлая", "s_theme_dark": "Тёмная",
 "s_theme_auto": "Автопереключение по времени системы",
 "s_theme_time": "Тёмный период (24ч, напр. 19:00–07:00)",
 "s_audio": "Звук",
 "s_hotkey": "Горячая клавиша старта / стопа",
 "s_hotkey_enable": "Включить глобальную горячую клавишу",
 "s_hotkey_capture": "Нажмите здесь, затем комбинацию клавиш",
 "s_guard": "Защита от окруж. шума (Ферма / Долина)",
 "s_guard_enable": "Включить предобработку окруж. шума",
 "s_guard_gate": "Шумоподавитель (постоянный фон)",
 "s_guard_spectral": "Спектральное вычитание окруж. шума (Ферма / Долина)",
 "s_guard_note": "Подготовленные функции BETA, по умолчанию выкл.; следите за распознаванием",
 "s_guard_hotkey_enable": "Включить горячую клавишу вкл/выкл защиты",
 "home_guard": "Анти-шум",
 "home_guard_on": "Анти-шум: ВКЛ",
 "guard_on": "Защита от окруж. шума включена (Ферма / Долина)",
 "guard_off": "Защита от окруж. шума выключена",
 "license_title": "Лицензионное соглашение и отказ от ответственности",
 "license_check": "Я прочитал и обязуюсь соблюдать это соглашение",
 "license_accept": "Принять и продолжить",
 "license_decline": "Отклонить и выйти",
 "license_missing": "Файл соглашения не найден. Получите EULA.md из комплекта поставки.",
 "s_security": "Конфиденциальность и безопасность",
 "s_capture_protect": "Скрыть окна из захвата экрана / записи",
 "s_protected_procs": "Защищённые процессы: автоскрытие программы во время их работы",
 "s_proc_action": "При обнаружении защищённого процесса",
 "s_act_capture": "Оставить видимым, но блокировать захват (рекоменд.)",
 "s_act_overlay": "Скрыть только оверлей",
 "s_act_all": "Скрыть все окна",
 "s_act_pause": "Приостановить прослушивание",
 "s_add_proc": "Добавить",
 "s_remove": "Удалить", "s_reset": "По умолчанию",
 "s_saved": "Настройки сохранены автоматически",
 "about_title": "О программе",
 "about_desc": "Детектор звука золотых предметов для Arena Breakout: Infinite",
 "about_dev": "Разработчики", "about_github": "GitHub", "about_author": "ND",
 "about_disclaimer": "Звук захватывается и анализируется локально; игровой процесс не изменяется, риска бана нет. Только для личного обучения и исследований.",
 "log_devices_found": "Найдено доступных источников звука: {n}",
 "log_no_device": "⚠️ Нет доступных источников звука",
 "log_started": "🎧 Прослушивание начато: {dev}, шаблонов {n}",
 "log_stopped": "■ Прослушивание остановлено",
 "log_start_fail": "Не удалось начать: {e}",
 "log_recognized": "🎯 {name} ({file}, счёт {s}, разница {m})",
 "log_capture_err": "Ошибка захвата: {msg}",
 "log_select_source": "Выберите действительный источник звука",
 "hk_registered": "Горячая клавиша зарегистрирована: {hk}",
 "hk_failed": "Не удалось зарегистрировать: {hk} (возможно, занято)",
 "protected_hide": "Обнаружен защищённый процесс, окна скрыты",
 "protected_show": "Защищённый процесс завершён, окна восстановлены",
},
}


# --------------------------------------------------------------------------
# 物品名（与语言无关的 key -> 四语言）
# --------------------------------------------------------------------------

ITEMS_RAW = {
 # 第一组
 "teapot":   ("古董茶壶", "Antique Teapot", "アンティークティーポット", "Старинный чайник"),
 "vase":     ("花瓶", "Vase", "花瓶", "Ваза"),
 "necklace": ("宝石项链 / 卡莫纳之心", "Gem Necklace / Heart of Kamona",
              "宝石ネックレス / カモナの心", "Ожерелье / Сердце Камоны"),
 "lion":     ("狮子（6格）", "Lion (6-grid)", "ライオン（6マス）", "Лев (6 яч.)"),
 # 第二组
 "classified_docs": ("机密文件", "Classified Documents", "機密文書", "Секретные документы"),
 "thermal_module": ("热成像模块", "Thermal Imaging Module", "サーマルモジュール", "Тепловизорный модуль"),
 "target_locator": ("目标定位模块", "Target Locator Module", "目標測位モジュール", "Модуль целеуказания"),
 "antenna": ("天线", "Antenna", "アンテナ", "Антенна"),
 "artillery_scope": ("炮队镜", "Artillery Scope", "砲隊鏡", "Артиллерийская труба"),
 "oscilloscope": ("示波器", "Oscilloscope", "オシロスコープ", "Осциллограф"),
 "game_console": ("游戏机", "Game Console", "ゲーム機", "Игровая приставка"),
 # 第三组
 "gyroscope": ("三轴陀螺仪", "Three-Axis Gyroscope", "3軸ジャイロ", "Трёхосевой гироскоп"),
 "hemera_menu": ("赫美拉菜单", "Hemera Menu", "ヘメラメニュー", "Меню «Гемера»"),
 "lens_array": ("整列镜片", "Lens Array", "レンズアレイ", "Набор линз"),
 "capsule_tv": ("胶囊电视", "Capsule TV", "カプセルTV", "Капсульный ТВ"),
 "chaos_matter": ("混沌质", "Chaos Matter", "カオス物質", "Вещество хаоса"),
 "armillary": ("承天浑仪", "Armillary Sphere", "浑儀", "Армиллярная сфера"),
 "quantum2000": ("量子2000", "Quantum 2000", "量子2000", "Квантум 2000"),
 "lyre": ("里拉琴", "Lyre", "リラ", "Лира"),
 "prototype_module": ("原型机模块", "Prototype Module", "プロトタイプモジュール", "Модуль прототипа"),
 "rebar_cutter": ("钢筋剪", "Rebar Cutter", "鉄筋カッター", "Кусачки для арматуры"),
 "hydraulic_wrench": ("液压扳手", "Hydraulic Wrench", "油圧レンチ", "Гидравлический ключ"),
 "drill": ("电钻", "Power Drill", "電動ドリル", "Дрель"),
 "tool_kit": ("工具套组", "Tool Kit", "ツールキット", "Набор инструментов"),
 "artillery_shell": ("炮弹", "Artillery Shell", "砲弾", "Артиллерийский снаряд"),
 # 第四组
 "destiny_tablet": ("大金天命泥板", "Destiny Clay Tablet", "天命の粘土板", "Глиняная табличка судьбы"),
 "utopia": ("理想国", "Utopia", "理想郷", "Утопия"),
 "steel_pipe": ("钢管", "Steel Pipe", "スチールパイプ", "Стальная труба"),
 "car_battery": ("汽车蓄电池", "Car Battery", "カーバッテリー", "Автомобильный аккумулятор"),
 "titanium_plate": ("钛合金钢板", "Titanium Alloy Plate", "チタン合金板", "Титановая пластина"),
 # 第五组
 "golden_mask": ("大金黄金面具", "Golden Mask", "黄金マスク", "Золотая маска"),
 "aerospace_navigator": ("航天导航仪", "Aerospace Navigator", "宇宙ナビゲーター", "Аэрокосмический навигатор"),
 "peacock_feather": ("孔雀羽山", "Peacock Feather", "孔雀の羽", "Павлинье перо"),
 "true_matrix": ("真实矩阵", "True Matrix", "トゥルーマトリックス", "Истинная матрица"),
 "birdcage": ("鸟笼", "Birdcage", "鳥かご", "Птичья клетка"),
 "dawn": ("黎明", "Dawn", "夜明け", "Рассвет"),
 "robotic_arm": ("机械手臂", "Robotic Arm", "ロボットアーム", "Роборука"),
 "aerospace_case": ("航太实验箱", "Aerospace Experiment Case", "宇宙実験ケース", "Аэрокосмический кейс"),
 "glucose_kit": ("血糖仪套装", "Blood Glucose Meter Kit", "血糖計キット", "Набор глюкометра"),
 "wiesel_diary": ("维塞尔日记", "Wiesel's Diary", "ヴィーゼルの日記", "Дневник Визеля"),
 "planet_child": ("行星之子", "Child of the Planet", "星の子", "Дитя планеты"),
 "nonlinear_detector": ("非线性探测仪", "Nonlinear Detector", "非線形検出器", "Нелинейный детектор"),
 "military_kit": ("军用工具包", "Military Toolkit", "軍用ツールキット", "Военный набор инструментов"),
 # 第六组
 "white_snake": ("白蛇金像", "White Snake Golden Statue", "白蛇の黄金像", "Золотая статуя белой змеи"),
 "photoelectric_model": ("光电模型", "Photoelectric Model", "光電モデル", "Фотоэлектрическая модель"),
 "feast_statue": ("盛宴雕像", "Feast Statue", "饗宴の像", "Статуя пира"),
 "plaster_statue": ("石膏雕像", "Plaster Statue", "石膏像", "Гипсовая статуя"),
 "cipher_x7l": ("X7-L密码机", "X7-L Cipher Machine", "X7-L暗号機", "Шифратор X7-L"),
}
ITEMS = {k: dict(zip(("zh", "en", "ja", "ru"), v)) for k, v in ITEMS_RAW.items()}

GROUP_NAMES = {
 1: ("第一组", "Group 1", "第1グループ", "Группа 1"),
 2: ("第二组大金", "Group 2 Gold", "第2グループ大金", "Группа 2 — золото"),
 3: ("第三组大金", "Group 3 Gold", "第3グループ大金", "Группа 3 — золото"),
 4: ("第四组大金", "Group 4 Gold", "第4グループ大金", "Группа 4 — золото"),
 5: ("第五组大金", "Group 5 Gold", "第5グループ大金", "Группа 5 — золото"),
 6: ("第六组大金", "Group 6 Gold", "第6グループ大金", "Группа 6 — золото"),
}


# --------------------------------------------------------------------------
# I18n 门面
# --------------------------------------------------------------------------

class I18n:
    def __init__(self, lang=None):
        if lang not in dict(LANGS):
            lang = detect_system_language()
        self.lang = lang if lang in STR else DEFAULT_LANG

    def set_lang(self, lang):
        if lang in STR:
            self.lang = lang

    def t(self, key, **kw):
        s = STR.get(self.lang, STR[DEFAULT_LANG]).get(key)
        if s is None:
            s = STR[DEFAULT_LANG].get(key, key)
        if kw:
            try:
                s = s.format(**kw)
            except Exception:
                pass
        return s

    def item(self, key):
        d = ITEMS.get(key)
        if not d:
            return key
        return d.get(self.lang) or d[DEFAULT_LANG]

    def group(self, n):
        g = GROUP_NAMES.get(n)
        if not g:
            return str(n)
        idx = ("zh", "en", "ja", "ru").index(self.lang) if self.lang in ("zh", "en", "ja", "ru") else 1
        return g[idx]
