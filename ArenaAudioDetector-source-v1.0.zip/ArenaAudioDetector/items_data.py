# -*- coding: utf-8 -*-
"""
items_data.py —— 物品逻辑树（与界面语言无关）
================================================================
以 wav 模板文件为键，描述命中后应显示的结构：
  single : 单件识别（第一组 5 个独立音效）
  group  : 组内共用音效（第二~六组），items 为 (物品key, 颜色)
颜色 color ∈ {"red","gold","purple"}（红 / 金 / 紫，依据最新 Name_list）。
物品的多语言名称由 i18n.ITEMS 提供；本文件只负责“结构 + 颜色”。
该数据同时驱动：识别浮窗、主页面“大金清单”表格、匹配器模板加载。
"""

RED, GOLD, PURPLE = "red", "gold", "purple"

ITEM_MAP = {
    # —— 第一组：5 段独立音效，可单件识别（均为红色收藏品） ——
    "g1_01.wav": {"kind": "single", "item": "teapot", "color": RED},
    "g1_02.wav": {"kind": "single", "item": "vase", "color": RED},
    "g1_03.wav": {"kind": "single", "item": "necklace", "color": RED},
    "g1_04.wav": {"kind": "single", "item": "necklace", "color": RED},
    "g1_05.wav": {"kind": "single", "item": "lion", "color": RED},

    # —— 第二组：红(机密/热成像/定位) · 金(天线/炮队镜) · 紫(示波器/游戏机) ——
    "g2_common.wav": {"kind": "group", "group": 2, "items": [
        ("classified_docs", RED),
        ("thermal_module", RED),
        ("target_locator", RED),
        ("antenna", GOLD),
        ("artillery_scope", GOLD),
        ("oscilloscope", PURPLE),
        ("game_console", PURPLE),
    ]},

    # —— 第三组：红 9 · 紫 4(钢筋剪/电钻/工具套组/炮弹) · 金(液压扳手) ——
    "g3_common.wav": {"kind": "group", "group": 3, "items": [
        ("gyroscope", RED),
        ("hemera_menu", RED),
        ("lens_array", RED),
        ("capsule_tv", RED),
        ("chaos_matter", RED),
        ("armillary", RED),
        ("quantum2000", RED),
        ("lyre", RED),
        ("prototype_module", RED),
        ("rebar_cutter", PURPLE),
        ("drill", PURPLE),
        ("tool_kit", PURPLE),
        ("artillery_shell", PURPLE),
        ("hydraulic_wrench", GOLD),
    ]},

    # —— 第四组：红(天命泥板/理想国) · 紫(钢管) · 金(蓄电池/钛合金板) ——
    "g4_common.wav": {"kind": "group", "group": 4, "items": [
        ("destiny_tablet", RED),
        ("utopia", RED),
        ("steel_pipe", PURPLE),
        ("car_battery", GOLD),
        ("titanium_plate", GOLD),
    ]},

    # —— 第五组：红 7 · 金(实验箱/血糖仪/日记) · 紫(行星之子/非线性/军用包) ——
    "g5_common.wav": {"kind": "group", "group": 5, "items": [
        ("golden_mask", RED),
        ("aerospace_navigator", RED),
        ("peacock_feather", RED),
        ("true_matrix", RED),
        ("birdcage", RED),
        ("dawn", RED),
        ("robotic_arm", RED),
        ("aerospace_case", GOLD),
        ("glucose_kit", GOLD),
        ("wiesel_diary", GOLD),
        ("planet_child", PURPLE),
        ("nonlinear_detector", PURPLE),
        ("military_kit", PURPLE),
    ]},

    # —— 第六组：红(白蛇/光电/盛宴) · 紫(石膏像) · 金(X7-L密码机) ——
    "g6_common.wav": {"kind": "group", "group": 6, "items": [
        ("white_snake", RED),
        ("photoelectric_model", RED),
        ("feast_statue", RED),
        ("plaster_statue", PURPLE),
        ("cipher_x7l", GOLD),
    ]},
}

# 模板文件顺序（匹配器按此加载）
TEMPLATE_WAVS = list(ITEM_MAP.keys())


def entry_for_wav(wav_name):
    return ITEM_MAP.get(wav_name)
