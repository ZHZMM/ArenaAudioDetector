# -*- mode: python ; coding: utf-8 -*-
"""ArenaAudioDetector BETA —— PyInstaller 打包配置（路径自适应，可直接运行）"""
import os
import glob
from PyInstaller.utils.hooks import collect_all

block_cipher = None
HERE = os.path.abspath(SPECPATH)

# —— 只读资源：模板 wav + config.json（打到 exe 内，运行时解压到 _MEIPASS） ——
datas = []
for w in sorted(glob.glob(os.path.join(HERE, "*.wav"))):
    datas.append((w, "."))
_cfg = os.path.join(HERE, "config.json")
if os.path.exists(_cfg):
    datas.append((_cfg, "."))

# —— 环境音样本（农场 / 山谷）-> env/ 子目录 ——
_envdir = os.path.join(HERE, "env")
if os.path.isdir(_envdir):
    for w in sorted(glob.glob(os.path.join(_envdir, "*.wav"))):
        datas.append((w, "env"))

# —— 开源许可 / 用户协议 ——
for _doc in ("LICENSE", "EULA.md"):
    _p = os.path.join(HERE, _doc)
    if os.path.exists(_p):
        datas.append((_p, "."))

# —— pyaudiowpatch（WASAPI 环回） ——
pkg_datas, pkg_bin, pkg_hidden = collect_all("pyaudiowpatch")
datas += pkg_datas
binaries = pkg_bin
hiddenimports = [
    "pyaudiowpatch",
    "_portaudiowpatch",          # C 扩展（位于 site-packages 根）
    "sounddevice",
    "numpy",
] + pkg_hidden

a = Analysis(
    [os.path.join(HERE, "main.py")],
    pathex=[HERE],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["librosa", "matplotlib", "PyQt5", "PySide2"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="ArenaAudioDetector",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
