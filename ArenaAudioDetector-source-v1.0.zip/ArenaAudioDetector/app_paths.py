# -*- coding: utf-8 -*-
"""
app_paths.py —— 资源与用户数据路径（兼容源码运行与 PyInstaller 打包）
================================================================
- 只读资源（wav 模板 / config.json）：打包后在 sys._MEIPASS，源码时在项目目录；
- 用户可写数据（settings.json）：%APPDATA%\\ArenaAudioDetector，保证可写。
"""

import os
import sys

APP_NAME = "ArenaAudioDetector"


def is_frozen():
    return getattr(sys, "frozen", False)


def resource_dir():
    if is_frozen():
        return getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def resource_path(rel):
    return os.path.join(resource_dir(), rel)


def user_data_dir():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, APP_NAME)
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def user_settings_path():
    return os.path.join(user_data_dir(), "settings.json")
