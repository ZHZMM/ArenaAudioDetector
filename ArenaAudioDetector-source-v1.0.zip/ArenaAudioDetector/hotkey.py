# -*- coding: utf-8 -*-
"""
hotkey.py —— 全局开始/停止监听快捷键（Windows RegisterHotKey，ctypes 实现）
================================================================
- 默认 Ctrl+Alt+S，可在“设置”中自定义（Ctrl/Alt/Shift/Win + 任意按键）；
- 在独立线程内注册热键并以 PeekMessage 轮询，触发时回调（切换监听）；
- 不依赖第三方键盘库，打包稳定。
"""

import ctypes
import ctypes.wintypes as wt
import threading
import time

user32 = ctypes.windll.user32

MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_WIN = 0x0008
MOD_NOREPEAT = 0x4000

WM_HOTKEY = 0x0312
WM_QUIT = 0x0012
PM_REMOVE = 0x0001
HOT_ID = 0xB001

_MOD_BITS = {
    "CTRL": MOD_CONTROL, "CONTROL": MOD_CONTROL,
    "ALT": MOD_ALT, "SHIFT": MOD_SHIFT,
    "WIN": MOD_WIN, "META": MOD_WIN, "SUPER": MOD_WIN,
}

_SPECIAL_KEYS = {
    "SPACE": 0x20, "INS": 0x2D, "INSERT": 0x2D,
    "DEL": 0x2E, "DELETE": 0x2E,
    "HOME": 0x24, "END": 0x23,
    "PGUP": 0x21, "PAGEUP": 0x21,
    "PGDN": 0x22, "PAGEDOWN": 0x22,
    "UP": 0x26, "DOWN": 0x28, "LEFT": 0x25, "RIGHT": 0x27,
    "TAB": 0x09, "ENTER": 0x0D, "RETURN": 0x0D,
    "CAPSLOCK": 0x14, "NUMLOCK": 0x90, "SCROLLLOCK": 0x91,
    "PRINTSCREEN": 0x2C, "PAUSE": 0x13,
    "NUMPAD0": 0x60, "NUMPAD1": 0x61, "NUMPAD2": 0x62, "NUMPAD3": 0x63,
    "NUMPAD4": 0x64, "NUMPAD5": 0x65, "NUMPAD6": 0x66, "NUMPAD7": 0x67,
    "NUMPAD8": 0x68, "NUMPAD9": 0x69,
    "MULTIPLY": 0x6A, "ADD": 0x6B, "SUBTRACT": 0x6D, "DECIMAL": 0x6E, "DIVIDE": 0x6F,
}


def key_to_vk(key):
    key = key.strip().upper()
    if len(key) == 1 and key.isalnum():
        return ord(key)
    if key.startswith("F") and key[1:].isdigit():
        n = int(key[1:])
        if 1 <= n <= 24:
            return 0x70 + (n - 1)
    if key in _SPECIAL_KEYS:
        return _SPECIAL_KEYS[key]
    # 兜底：VkKeyScanW
    res = user32.VkKeyScanW(ctypes.c_wchar(key[0] if key else " "))
    vk = res & 0xFF
    return vk if vk != 0xFF else None


def vk_to_key(vk, mods=0):
    def is_in(v, table):
        return False
    # F 键
    if 0x70 <= vk <= 0x87:
        return "F%d" % (vk - 0x6F)
    # 常见可打印字符
    if 0x30 <= vk <= 0x5A:
        return chr(vk)
    for name, code in _SPECIAL_KEYS.items():
        if code == vk and len(name) > 3:
            pretty = {"INSERT": "Insert", "DELETE": "Delete", "HOME": "Home",
                      "END": "End", "PAGEUP": "PgUp", "PAGEDOWN": "PgDn",
                      "SPACE": "Space", "UP": "Up", "DOWN": "Down",
                      "LEFT": "Left", "RIGHT": "Right", "TAB": "Tab"}
            return pretty.get(name, name.title())
    # 用 MapVirtualKey + GetKeyNameText 兜底
    scan = user32.MapVirtualKeyW(vk, 0) << 16
    buf = ctypes.create_unicode_buffer(32)
    if user32.GetKeyNameTextW(scan, buf, 32):
        return buf.value
    return "0x%02X" % vk


def parse_hotkey(s):
    "'Ctrl+Alt+S' -> (mods, vk)"
    parts = [p.strip().upper() for p in str(s).split("+") if p.strip()]
    mods = 0
    for p in parts[:-1]:
        mods |= _MOD_BITS.get(p, 0)
    vk = key_to_vk(parts[-1]) if parts else None
    return mods, vk


def format_hotkey(mods, vk):
    order = [(MOD_CONTROL, "Ctrl"), (MOD_ALT, "Alt"),
             (MOD_SHIFT, "Shift"), (MOD_WIN, "Win")]
    names = [label for bit, label in order if mods & bit]
    names.append(vk_to_key(vk, mods))
    return "+".join(names)


class MSG(ctypes.Structure):
    _fields_ = [("hwnd", wt.HWND), ("message", wt.UINT),
                ("wParam", wt.WPARAM), ("lParam", wt.LPARAM),
                ("time", wt.DWORD), ("pt", wt.POINT)]


class GlobalHotkey:
    def __init__(self, on_trigger=None, on_status=None, hot_id=HOT_ID):
        self.on_trigger = on_trigger
        self.on_status = on_status          # (ok:bool, hotkey:str, err:str|None)
        self.hot_id = hot_id
        self._want = False
        self.thread = None
        self.current = None
        self._registered = False

    # 注册并启动（返回是否成功，通过线程内事件回传）
    def start(self, hotkey_str):
        self.stop()
        mods, vk = parse_hotkey(hotkey_str)
        if vk is None:
            if self.on_status:
                self.on_status(False, hotkey_str, "bad key")
            return False
        self.current = format_hotkey(mods, vk)
        self._want = True
        ready = threading.Event()
        result = {"ok": False}

        def run():
            ok = bool(user32.RegisterHotKey(None, self.hot_id,
                                            mods | MOD_NOREPEAT, vk))
            result["ok"] = ok
            ready.set()
            if not ok:
                if self.on_status:
                    err = ctypes.get_last_error()
                    self.on_status(False, self.current, "err=%s" % err)
                return
            self._registered = True
            if self.on_status:
                self.on_status(True, self.current, None)
            msg = MSG()
            while self._want:
                while user32.PeekMessageW(ctypes.byref(msg), None,
                                          0, 0, PM_REMOVE):
                    if msg.message == WM_HOTKEY:
                        if self.on_trigger:
                            try:
                                self.on_trigger()
                            except Exception:
                                pass
                    elif msg.message == WM_QUIT:
                        self._want = False
                time.sleep(0.02)
            try:
                user32.UnregisterHotKey(None, self.hot_id)
            except Exception:
                pass
            self._registered = False

        self.thread = threading.Thread(target=run, daemon=True)
        self.thread.start()
        ready.wait(1.0)
        return result["ok"]

    def stop(self):
        self._want = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.0)
        self.thread = None
        self._registered = False
