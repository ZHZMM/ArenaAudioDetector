# -*- coding: utf-8 -*-
"""
audio_capture.py —— 统一音频采集（WASAPI 环回 + 常规输入）
================================================================
两种采集后端：
  ① loopback（默认首选，pyaudiowpatch）：直接捕获“播放设备”的混音输出。
     只要游戏声音能从耳机/音箱听到就能抓到，无需立体声混音、无需 VB-CABLE、
     无需任何路由配置，也不需要管理员权限 —— 专门解决“抓不到游戏声”。
  ② input（sounddevice）：麦克风 / CABLE Output / 立体声混音等常规输入，
     打不开时自动回退系统默认输入。

统一输出：单声道 float32、约 chunk_ms 的数据块，经队列交给识别线程。
"""

import queue
import threading
import numpy as np


# --------------------------------------------------------------------------
# 设备枚举
# --------------------------------------------------------------------------

def list_sources():
    """枚举全部可选音频源。
    返回 list[dict]：{kind, index, name, sr, channels, default}
    kind = "loopback"（播放设备环回）或 "input"（常规录音设备）
    """
    sources = []

    # ① 环回设备（pyaudiowpatch / WASAPI）
    try:
        import pyaudiowpatch as pyaudio
        p = pyaudio.PyAudio()
        try:
            default_lb = None
            try:
                default_lb = p.get_default_wasapi_loopback()
            except Exception:
                default_lb = None

            seen = set()
            for d in p.get_loopback_device_info_generator():
                idx = int(d["index"])
                if idx in seen:
                    continue
                seen.add(idx)
                is_default = bool(default_lb is not None
                                  and idx == int(default_lb["index"]))
                raw_name = d["name"].replace("[Loopback]", "").strip()
                sources.append({
                    "kind": "loopback",
                    "index": idx,
                    "name": raw_name,
                    "sr": int(d["defaultSampleRate"]),
                    "channels": int(d["maxInputChannels"]) or 2,
                    "default": is_default,
                })
        finally:
            p.terminate()
    except Exception as e:
        print("[audio] 环回设备枚举失败:", e)

    # 默认输出对应的环回排第一
    sources.sort(key=lambda s: 0 if s.get("default") else 1)

    # ② 常规输入设备（sounddevice）
    try:
        import sounddevice as sd
        for i, d in enumerate(sd.query_devices()):
            if d["max_input_channels"] > 0:
                sources.append({
                    "kind": "input",
                    "index": i,
                    "name": d["name"],
                    "sr": int(d["default_samplerate"]),
                    "channels": min(2, int(d["max_input_channels"])),
                    "default": False,
                })
    except Exception as e:
        print("[audio] 常规输入设备枚举失败:", e)

    return sources


def source_key(src):
    return "%s:%d" % (src["kind"], src["index"])


# --------------------------------------------------------------------------
# 统一采集器
# --------------------------------------------------------------------------

class AudioCapture:
    """根据 source 描述打开相应后端，输出统一的单声道 float32 数据块。"""

    def __init__(self, source, chunk_ms=250, on_error=None):
        self.kind = source["kind"]
        self.device = source["index"]
        self.device_name = source["name"]
        self.samplerate = int(source["sr"])
        self.channels = max(1, int(source.get("channels") or 2))
        self.chunk_ms = chunk_ms
        self.chunk_size = int(self.samplerate * chunk_ms / 1000)

        self.q = queue.Queue(maxsize=200)
        self.running = False
        self.thread = None
        self.last_rms = 0.0
        self.on_error = on_error

    # ---------------- 生命周期 ----------------
    def start(self):
        if self.running:
            return
        self.running = True
        target = self._loop_loopback if self.kind == "loopback" else self._loop_input
        self.thread = threading.Thread(target=target, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2.0)
        self.thread = None

    def get_audio_chunk(self, timeout=0.5):
        try:
            return self.q.get(timeout=timeout)
        except queue.Empty:
            return None

    def _emit(self, x):
        x = np.ascontiguousarray(x, dtype=np.float32)
        self.last_rms = float(np.sqrt((x ** 2).mean() + 1e-12))
        if not self.q.full():
            self.q.put(x.copy())

    @staticmethod
    def _to_mono(data):
        if data.ndim > 1:
            data = data.mean(axis=1)
        return data

    # ---------------- 后端①：WASAPI 环回 ----------------
    def _loop_loopback(self):
        import pyaudiowpatch as pyaudio
        import sounddevice as sd

        p = pyaudio.PyAudio()
        # 候选：指定环回 -> 默认环回
        candidates = [self.device]
        try:
            dflt = p.get_default_wasapi_loopback()
            if dflt and int(dflt["index"]) not in candidates:
                candidates.append(int(dflt["index"]))
        except Exception:
            pass

        ch = self.channels
        sr = self.samplerate
        block = max(256, int(sr * self.chunk_ms / 1000))

        def callback(in_data, frame_count, time_info, status):
            arr = np.frombuffer(in_data, dtype=np.float32)
            if ch > 1:
                arr = arr.reshape(frame_count, ch)
            self._emit(self._to_mono(arr))
            return (None, pyaudio.paContinue)

        last_err = None
        stream = None
        for dev in candidates:
            try:
                stream = p.open(format=pyaudio.paFloat32, channels=ch, rate=sr,
                                input=True, input_device_index=dev,
                                frames_per_buffer=block,
                                stream_callback=callback)
                stream.start_stream()
                self.device = dev
                try:
                    self.device_name = p.get_device_info_by_index(dev)["name"]\
                        .replace("[Loopback]", "").strip()
                except Exception:
                    pass
                print("[audio] ✅ 环回采集已启动: [%d] %s" % (dev, self.device_name))
                if self.on_error:
                    self.on_error(None)
                while self.running and stream.is_active():
                    sd.sleep(50)
                break
            except Exception as e:
                last_err = e
                msg = "环回设备 [%d] 打开失败: %s" % (dev, e)
                print("[audio error]", msg)
                if self.on_error:
                    self.on_error(msg)
            finally:
                try:
                    if stream is not None:
                        stream.stop_stream()
                        stream.close()
                except Exception:
                    pass
                stream = None

        if not self.running:
            pass
        elif stream is None and last_err is not None:
            msg = "所有环回设备均打开失败: %s" % last_err
            print("[audio error]", msg)
            if self.on_error:
                self.on_error(msg)

        try:
            p.terminate()
        except Exception:
            pass

    # ---------------- 后端②：常规输入（sounddevice） ----------------
    def _loop_input(self):
        import sounddevice as sd

        def cb(indata, frames, t, status):
            if status:
                print("[audio status]", status)
            x = indata.astype("float32")
            self._emit(self._to_mono(x))

        candidates = [self.device]
        dflt = sd.default.device[0]
        if dflt not in candidates and dflt is not None:
            candidates.append(dflt)

        last_err = None
        for dev in candidates:
            try:
                with sd.InputStream(
                    device=dev,
                    channels=self.channels,
                    samplerate=self.samplerate,
                    blocksize=self.chunk_size,
                    callback=cb,
                    dtype="float32",
                ):
                    self.device = dev
                    try:
                        self.device_name = sd.query_devices(dev)["name"]
                    except Exception:
                        pass
                    print("[audio] ✅ 常规采集已启动: [%d] %s" % (dev, self.device_name))
                    if self.on_error:
                        self.on_error(None)
                    while self.running:
                        sd.sleep(50)
                return
            except Exception as e:
                last_err = e
                msg = "录音设备 [%d] 打开失败: %s" % (dev, e)
                print("[audio error]", msg)
                if self.on_error:
                    self.on_error(msg)

        msg = "所有录音设备均打开失败: %s" % last_err
        print("[audio error]", msg)
        if self.on_error:
            self.on_error(msg)
