# -*- coding: utf-8 -*-
"""
theme.py —— 浅色 / 深色主题与按时间自动切换
================================================================
- theme_mode = "auto"：按系统当前时间判断（默认深色时段 19:00–07:00，跨午夜）；
- theme_mode = "light" / "dark"：手动覆盖（在设置中选择）；
- 颜色以调色板形式提供，UI 层在创建控件与切换主题时读取。
"""

from datetime import datetime

# 默认深色时段（24 小时制，支持跨午夜）
DEFAULT_DARK_START = "19:00"
DEFAULT_DARK_END = "07:00"

PALETTES = {
"light": {
 "name": "light",
 "bg": "#F4F3EE", "bg_sidebar": "#E9E7E0", "bg2": "#FFFFFF",
 "bg3": "#ECEAE3", "bg_hover": "#E3E1D9",
 "fg": "#1A1B1C", "fg_dim": "#6B7280",
 "border": "#D8D6CF", "accent": "#2563EB", "accent_hover": "#1D4FD7",
 "accent_fg": "#FFFFFF",
 "gold": "#B8860B", "gold_soft": "#FBF3DD",
 "green": "#2E9E44", "red": "#DC3A3A", "purple": "#8B3FD0",
 "nav_active": "#FFFFFF", "log_bg": "#FFFFFF",
 "canvas_bg": "#FFFFFF", "level_track": "#ECEAE3",
},
"dark": {
 "name": "dark",
 "bg": "#0F1115", "bg_sidebar": "#0B0D11", "bg2": "#161B22",
 "bg3": "#1C2330", "bg_hover": "#242C3B",
 "fg": "#E6EDF3", "fg_dim": "#8A94A6",
 "border": "#30363D", "accent": "#1F6FEB", "accent_hover": "#388bfd",
 "accent_fg": "#FFFFFF",
 "gold": "#FFD700", "gold_soft": "#241F10",
 "green": "#3FB950", "red": "#F85149", "purple": "#C77DFF",
 "nav_active": "#1C2330", "log_bg": "#0C0F14",
 "canvas_bg": "#161B22", "level_track": "#1C2330",
},
}


def parse_hhmm(s):
    "'19:00' -> 19.0；失败返回 None"
    try:
        h, m = str(s).split(":")
        val = int(h) + int(m) / 60.0
        if 0.0 <= val < 24.0:
            return val
    except Exception:
        return None
    return None


def is_dark_time(now=None, start=DEFAULT_DARK_START, end=DEFAULT_DARK_END):
    """判断给定时刻是否处于深色时段（支持跨午夜）。"""
    if now is None:
        now = datetime.now()
    t = now.hour + now.minute / 60.0
    s = parse_hhmm(start)
    e = parse_hhmm(end)
    if s is None or e is None:
        # 兜底：19:00–07:00
        s, e = 19.0, 7.0
    if abs(s - e) < 1e-6:
        return False
    if s < e:                      # 同日区间，如 13:00–15:00
        return s <= t < e
    return t >= s or t < e         # 跨午夜，如 19:00–07:00


def effective_theme(settings=None, now=None):
    """根据设置返回当前应使用的主题名 'light' / 'dark'。"""
    settings = settings or {}
    mode = settings.get("theme_mode", "auto")
    if mode in ("light", "dark"):
        return mode
    dark = is_dark_time(
        now,
        start=settings.get("dark_start", DEFAULT_DARK_START),
        end=settings.get("dark_end", DEFAULT_DARK_END),
    )
    return "dark" if dark else "light"


class Theme:
    def __init__(self, name="dark"):
        self.name = name if name in PALETTES else "dark"
        self.c = PALETTES[self.name]

    @classmethod
    def from_settings(cls, settings=None, now=None):
        return cls(effective_theme(settings, now))

    def get(self, key, default=None):
        return self.c.get(key, default)

    def __getitem__(self, key):
        return self.c[key]
