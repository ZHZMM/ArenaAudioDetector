# ArenaAudioDetector

> 开源、免费、完全本地运行的 **音频频谱识别** 工具：实时监听本机扬声器播放的声音，
> 当出现《暗区突围：无限》的「大金 / 小紫」掉落、拾取音效时，在置顶浮窗中提示
> 物品名称与组别。**不读取游戏内存、不注入、不联网、不上传任何数据。**

Open-source, free, fully offline **audio spectrum recognition** tool. It listens to your
speakers via Windows WASAPI loopback and shows an overlay when in-game loot sound effects
play. It does **not** touch game memory, inject into processes, or use the network.

---

## 特性 / Features

- **WASAPI 环回采集**：直接抓取播放设备的系统声音，无需虚拟音频线、无需管理员权限。
- **音频指纹匹配**：MFCC / 频谱特征 + 余弦相似度，判定阈值 + 置信度边界双重校验。
- **红 / 金 / 紫三色**：按物品品质在浮窗与清单中以对应颜色显示。
- **抗环境音（农场 / 山谷）**：基于随程序提供的环境样本做谱减，可一键开关。
- **多语言**：中文 / English / 日本語 / Русский，默认跟随系统语言，识别失败回退英文。
- **浅色 / 深色主题**：按系统时间自动切换，也可手动指定。
- **全局快捷键**：默认 `Ctrl+Alt+S` 开始/停止监听、`Ctrl+Alt+G` 开关抗干扰，均可自定义。
- **隐私安全**：窗口默认防屏幕捕获；检测到受保护进程时可自动隐藏浮窗。

## 工作原理 / How it works

```
扬声器声音 ──WASAPI loopback──▶ 采集块 ──(可选)抗干扰谱减──▶ 滚动窗口
   ──▶ 音频指纹(MFCC/频谱) ──▶ 与模板库余弦匹配 ──▶ 置顶浮窗 / 日志
```

所有计算均在本机完成，程序不包含任何网络通信模块。

## 下载 / Downloads

发行版提供三种产物（见 Releases）：

1. **源码包** `ArenaAudioDetector-source-v1.0.zip` —— 用于阅读 / 二次开发 / 自行打包。
2. **集成安装包** `ArenaAudioDetector-Setup-v1.0.exe` —— 常规安装向导，自动创建快捷方式。
3. **便携包** `ArenaAudioDetector-portable-v1.0.zip` —— 解压即用，无需安装。

## 从源码运行 / Run from source

需要 Python 3.10+（推荐 3.12）：

```bash
pip install -r requirements.txt
python main.py
```

自行打包为单文件 exe：

```bash
pyinstaller ArenaAudioDetector.spec --noconfirm
```

## 使用 / Usage

1. 启动后在「主页」选择监听设备（带 ★ 的默认环回设备即可）。
2. 点击「开始监听」或按 `Ctrl+Alt+S`；右上角浮窗进入等待状态。
3. 游戏内出现大金音效时，浮窗显示物品（组音效显示该组全部可能物品）。
4. 在「农场 / 山谷」受环境音干扰时，点主页「抗干扰」或按 `Ctrl+Alt+G`。
5. 「设置」页可调整语言、主题、灵敏度、快捷键、安全选项。

> 首次启动需阅读并同意用户协议（EULA）。

## 项目结构 / Structure

| 文件 | 说明 |
| --- | --- |
| `main.py` | 主程序、应用壳、识别线程编排 |
| `audio_capture.py` | WASAPI 环回 / 输入设备枚举与采集 |
| `audio_recognizer.py` | 音频指纹特征提取与匹配算法 |
| `matcher.py` | 高层识别封装（阈值 / 冷却） |
| `audio_guard.py` | 抗环境音（噪声门 / 谱减） |
| `items_data.py` | 物品逻辑树与红/金/紫颜色 |
| `overlay.py` | 置顶识别浮窗 |
| `page_home.py / page_settings.py / page_about.py` | 主页 / 设置 / 关于 |
| `i18n.py` | 四语言文案 |
| `theme.py` | 浅 / 深主题与自动切换 |
| `hotkey.py` | Windows 全局快捷键 |
| `security.py` | 防屏幕捕获 / 进程监控 |
| `env/` | 农场 / 山谷环境音样本 |
| `*.wav` | 识别模板 |
| `EULA.md` | 用户协议与免责声明 |
| `LICENSE` | MIT 许可证 |

## 隐私 / Privacy

本软件不收集、不存储、不传输任何个人身份信息；用户设置仅保存在本机
（`%APPDATA%\ArenaAudioDetector\settings.json`）。

## 免责声明 / Disclaimer

本项目为 **非官方、非商业** 的学习项目，与任何游戏的开发商、发行商无关联。
游戏名称、音效、商标等知识产权归各自权利人所有。软件按「现状」提供，作者不对
使用后果（包括账号封停、数据损失）负责。请遵守游戏服务条款，详见 [EULA.md](EULA.md)。

## 许可证 / License

[MIT](LICENSE)

## 开发者 / Credits

- GitHub: **[ZHZHMM](https://github.com/ZHZHMM)**
- 原作者 / Original author: **ND 著**
