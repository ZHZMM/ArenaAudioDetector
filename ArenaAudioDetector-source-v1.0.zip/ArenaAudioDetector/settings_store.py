# -*- coding: utf-8 -*-
"""
settings_store.py —— 用户设置持久化（settings.json）
================================================================
首次启动使用默认值（语言跟随系统、主题按时间自动、环回设备、防护开启等），
设置变更后自动保存到 %APPDATA%\\ArenaAudioDetector\\settings.json。
"""

import copy
import json

from app_paths import user_settings_path

DEFAULT_SETTINGS = {
    # —— 语言 / 主题 ——
    "language": "auto",                 # auto=跟随系统，或 zh/en/ja/ru
    "theme_mode": "auto",               # auto/light/dark
    "dark_start": "19:00",
    "dark_end": "07:00",

    # —— 音频源 / 灵敏度记忆 ——
    "selected_source": None,            # 形如 {"kind":"loopback","index":82}
    "sensitivity": 80,

    # —— 全局快捷键 ——
    "hotkey_enabled": True,
    "hotkey": "Ctrl+Alt+S",             # 开始/停止监听（toggle）

    # —— 抗环境音（农场 / 山谷） ——
    "guard_enabled": False,             # 抗干扰总开关（默认关）
    "guard_gate": False,                # 附加噪声门
    "guard_spectral": True,             # 主用：环境谱减
    "gate_threshold": 0.01,
    "guard_hotkey_enabled": True,
    "guard_hotkey": "Ctrl+Alt+G",       # 抗干扰开/关快捷键

    # —— 首次用户协议 ——
    "license_agreed": False,

    # —— 隐私与安全 ——
    "capture_protect": True,            # 窗口防屏幕捕获/录屏
    "protected_action": "capture",      # capture=仅防捕获(默认) / overlay / all / pause
    "protected_processes": [
        "UAGame.exe",
        "arena_breakout_infinite_launcher.exe",
        "ArenaBreakoutInfiniteMiniloader.exe",
        "SGuard64.exe",
        "SGuardSvc64.exe",
    ],
}


def _deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


class SettingsStore:
    def __init__(self, path=None):
        self.path = path or user_settings_path()
        self.data = copy.deepcopy(DEFAULT_SETTINGS)
        self.load()

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                saved = json.load(f)
            self.data = _deep_merge(DEFAULT_SETTINGS, saved)
        except FileNotFoundError:
            pass
        except Exception as e:
            print("[settings] 读取失败，使用默认值:", e)

    def save(self):
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print("[settings] 保存失败:", e)

    def get(self, key, default=None):
        return self.data.get(key, default)

    def all(self):
        return self.data

    def update(self, **kw):
        self.data.update(kw)
        self.save()

    def reset(self):
        self.data = copy.deepcopy(DEFAULT_SETTINGS)
        self.save()
