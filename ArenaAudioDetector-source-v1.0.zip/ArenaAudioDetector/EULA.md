# ArenaAudioDetector 用户协议与免责声明（EULA）
# End-User License Agreement & Disclaimer

> 本软件为 **开源、免费、完全本地运行** 的音频频谱分析学习项目。
> This software is an **open-source, free, fully offline** audio spectrum-analysis
> learning project.

最近更新 / Last updated: 2026-10-02

---

## 一、软件性质与工作原理 / Nature & How it works

1. 本软件通过操作系统的“环回音频（loopback）”能力，**仅采集本机扬声器正在播放的声音**，
   在本地对其频谱特征进行比对，用于学习与研究音频指纹识别技术。
   The software only captures the audio being played through your own speakers via the
   operating-system loopback, and compares its spectral features **locally**, as a study
   of audio-fingerprinting technology.
2. 本软件 **不读取、不修改任何游戏的内存或数据，不注入进程，不模拟操作，不自动瞄准，
   不透视，不联网，不上传任何音频或个人信息**。
   It does **not** read or modify any game memory/data, inject into processes, automate
   input, aim, reveal hidden information, connect to the Internet, or upload any audio or
   personal information.
3. 所有识别均在你的电脑本地完成；软件不包含任何网络通信模块。
   All recognition happens locally on your computer; the program contains no networking
   module.

## 二、开源许可 / Open-source license

本软件源代码依据 **MIT 许可证** 开放（见随附 `LICENSE` 文件），项目地址：
GitHub — **ZHZHMM**；原作者署名：**ND 著**。
The source code is released under the **MIT License** (see the bundled `LICENSE`).
GitHub: **ZHZHMM**; original author credit: **ND**.

## 三、知识产权 / Intellectual property

1. 本项目为 **非官方、非商业** 的学习项目，与任何游戏的开发商、发行商 **无关联、
   未获其背书或授权**。
   This is an **unofficial, non-commercial** study project, **not affiliated with,
   endorsed or sponsored by** any game developer or publisher.
2. 文中出现的游戏名称、角色、物品、音效片段、商标及其他知识产权，均归各自权利人所有。
   引用仅用于说明与学习，不主张任何所有权。
   All game names, characters, items, sound clips, trademarks and other IP belong to their
   respective owners; they are referenced for illustration/study only, with no claim of
   ownership.

## 四、公平使用与行为限制 / Fair use & restrictions

你同意：You agree:
1. 遵守你所使用的任何游戏或服务的 **服务条款与社区规则**；如该条款禁止使用本类软件，
   你应自行停止使用。
   To comply with the **Terms of Service and community rules** of any game/service you use;
   if those terms prohibit software of this kind, you must stop using it.
2. 不利用本软件破坏游戏公平性、进行商业代练/牟利，或损害其他玩家的体验。
   Not to use it to harm game fairness, for commercial boosting/profit, or to spoil other
   players' experience.
3. 再分发本软件（修改与否）时，**保留原始版权、许可证、本协议与安全声明**，不得冒充
   官方产品，不得植入恶意代码或捆绑有害程序。
   When redistributing (modified or not), to **retain the original copyright, license, this
   agreement and safety notices**, not to impersonate an official product, and not to add
   malware or bundle harmful programs.

## 五、隐私与安全 / Privacy & security

1. 本软件不收集、不存储、不传输任何个人身份信息；设置仅保存在本机。
   The software collects, stores or transmits no personally identifiable information;
   settings are kept only on this machine.
2. 软件默认开启 **窗口防屏幕捕获**，并可在检测到指定进程时自动隐藏，以降低被其他程序
   识别或利用的风险；你可在设置中调整。
   Window anti-screen-capture is enabled by default, and the overlay can auto-hide when
   designated processes are detected, reducing the risk of other programs identifying or
   exploiting it. You can adjust this in Settings.

## 六、免责声明 / Disclaimer

1. 本软件按“**现状（AS IS）**”提供，不提供任何明示或默示的保证，包括但不限于适销性、
   特定用途适用性或不侵权。
   The software is provided "**AS IS**", without warranties of any kind, express or implied,
   including merchantability, fitness for a particular purpose, or non-infringement.
2. 识别结果可能因设备、音量、环境噪声等因素出现 **漏报或误报**，仅供参考。
   Results may be **missed or false** depending on device, volume and ambient noise, and are
   for reference only.
3. 在法律允许的最大范围内，作者及贡献者 **不对** 因使用或无法使用本软件而导致的任何
   直接或间接后果（包括但不限于账号被封停、数据损失、设备问题、利润或商誉损失）
   **承担责任**。是否使用由你自行判断并自担风险。
   To the maximum extent permitted by law, the authors and contributors shall **not be
   liable** for any direct or indirect consequence arising from using (or being unable to
   use) the software — including but not limited to account suspension, data loss, device
   issues, or loss of profits/goodwill. You use it at your own discretion and risk.

## 七、协议的接受、变更与终止 / Acceptance, changes & termination

1. 首次启动时，你需勾选“**我已阅读并同意遵守本协议**”后方可使用；不同意则应退出并删除
   本软件。
   On first launch you must check "**I have read and agree to comply**" before using the
   software; if you disagree, exit and delete it.
2. 作者可在新版本中更新本协议，继续使用即视为接受更新后的协议。
   The agreement may be updated in new releases; continued use constitutes acceptance.
3. 如你违反本协议，你的使用授权自动终止。
   Your right to use the software terminates automatically if you breach this agreement.

---

如对本协议有疑问，请通过 GitHub（ZHZHMM）提交 Issue。
For questions about this agreement, open an issue on GitHub (ZHZHMM).
