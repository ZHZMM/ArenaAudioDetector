# -*- coding: utf-8 -*-
"""
audio_guard.py —— 抗环境音（环境噪声抑制）模块
================================================================
针对地图“农场 / 山谷”的环境音，用随程序提供的环境样本（env/*.wav）
预先估计稳态环境噪声功率谱；用户开启“抗干扰”后，对采集块做谱减，
抑制与环境音相符的稳态成分，让突发的大金音效更突出。

组成：
  1. NoiseGate         波形噪声门（可选，抑制持续底噪）
  2. NoiseProfile      环境噪声功率谱估计（从 env 样本预置）
  3. spectral_subtract 谱减法（重叠相加重建）
  4. AudioGuard        统一门面：关闭时原样透传，开启后按设置处理

预处理与 audio_recognizer 的指纹/匹配算法完全解耦；默认关闭时零影响。
"""

import os
import glob

import numpy as np

from audio_recognizer import load_wav, _resample_linear


# --------------------------------------------------------------------------
# 1. 波形噪声门
# --------------------------------------------------------------------------

class NoiseGate:
    def __init__(self, threshold=0.01, sr=48000):
        self.threshold = float(threshold)
        self.sr = int(sr)

    def process(self, x):
        x = np.asarray(x, dtype=np.float32)
        n = max(1, int(0.01 * self.sr))
        out = x.copy()
        for i in range(0, len(x), n):
            seg = out[i:i + n]
            if seg.size == 0:
                continue
            rms = float(np.sqrt((seg ** 2).mean() + 1e-12))
            if rms < self.threshold:
                seg[:] = 0.0
        return out


# --------------------------------------------------------------------------
# 2. 环境噪声谱估计
# --------------------------------------------------------------------------

class NoiseProfile:
    """从若干“仅含环境声”的片段估计平均噪声功率谱。"""

    def __init__(self, n_fft=1024, hop=256):
        self.n_fft = n_fft
        self.hop = hop
        self._acc = None
        self._count = 0

    def feed(self, x):
        x = np.asarray(x, dtype=np.float32)
        if len(x) < self.n_fft:
            return
        win = np.hanning(self.n_fft)
        n_frames = 1 + (len(x) - self.n_fft) // self.hop
        idx = np.arange(self.n_fft)[None, :] + \
            self.hop * np.arange(n_frames)[:, None]
        frames = x[idx]
        spec = np.abs(np.fft.rfft(frames * win, n=self.n_fft, axis=1)) ** 2
        block = spec.mean(axis=0)
        if self._acc is None:
            self._acc = block
        else:
            self._acc += block
        self._count += 1

    @property
    def ready(self):
        return self._acc is not None and self._count > 0

    def noise_spectrum(self):
        if not self.ready:
            return None
        return (self._acc / self._count).astype(np.float32)

    def reset(self):
        self._acc = None
        self._count = 0


# --------------------------------------------------------------------------
# 3. 谱减法（波形级，重叠相加重建）
# --------------------------------------------------------------------------

def spectral_subtract(x, noise_power, n_fft=1024, hop=256,
                      oversub=1.6, floor=0.10):
    """oversub 越大抑制越强（但可能产生音乐噪声）；floor 保留谱下限避免空洞。"""
    x = np.asarray(x, dtype=np.float32)
    if len(x) < n_fft:
        return x
    win = np.hanning(n_fft)
    n_frames = 1 + (len(x) - n_fft) // hop
    idx = np.arange(n_fft)[None, :] + hop * np.arange(n_frames)[:, None]
    frames = x[idx]
    spec = np.fft.rfft(frames * win, n=n_fft, axis=1)
    mag = np.abs(spec)
    phase = np.angle(spec)

    clean_mag = mag ** 2 - oversub * noise_power[None, :]
    floor_mag = (floor * mag) ** 2
    clean_mag = np.sqrt(np.maximum(clean_mag, floor_mag))

    clean_frames = np.fft.irfft(clean_mag * np.exp(1j * phase),
                                n=n_fft, axis=1)
    out = np.zeros(len(x), dtype=np.float32)
    wsum = np.zeros(len(x), dtype=np.float32)
    for f in range(n_frames):
        s = f * hop
        out[s:s + n_fft] += clean_frames[f] * win
        wsum[s:s + n_fft] += win ** 2
    wsum[wsum < 1e-6] = 1.0
    return (out / wsum).astype(np.float32)


# --------------------------------------------------------------------------
# 4. 统一门面
# --------------------------------------------------------------------------

class AudioGuard:
    """按设置对采集块做抗环境音处理；关闭时原样透传。"""

    def __init__(self, settings=None, sample_rate=48000, env_dir=None):
        settings = settings or {}
        self.sr = int(sample_rate)
        self.enabled = bool(settings.get("guard_enabled", False))
        self.gate_enabled = bool(settings.get("guard_gate", False))
        # 抗干扰主用环境谱减；默认开启该项
        self.subtract_enabled = bool(settings.get("guard_spectral", True))
        self.gate = NoiseGate(float(settings.get("gate_threshold", 0.01)),
                              self.sr)
        self.profile = NoiseProfile()
        self._has_preset = False
        if env_dir and os.path.isdir(env_dir):
            self.load_env_samples(env_dir)

    def load_env_samples(self, env_dir):
        files = sorted(glob.glob(os.path.join(env_dir, "*.wav")))
        for f in files:
            try:
                y, sr = load_wav(f)
                if y.ndim > 1:
                    y = y.mean(axis=1)
                if sr != self.sr:
                    y = _resample_linear(y.astype(np.float64), sr,
                                         self.sr).astype(np.float32)
                self.profile.feed(y)
            except Exception:
                pass
        self._has_preset = self.profile.ready

    def set_enabled(self, flag):
        self.enabled = bool(flag)

    def process(self, chunk):
        if not self.enabled:
            return chunk
        out = chunk
        if self.gate_enabled:
            out = self.gate.process(out)
        if self.subtract_enabled and self._has_preset:
            noise = self.profile.noise_spectrum()
            if noise is not None:
                out = spectral_subtract(out, noise)
        return np.ascontiguousarray(out, dtype=np.float32)
