# -*- coding: utf-8 -*-
"""
overlay.py —— 置顶识别浮窗
================================================================
开始监听后在屏幕右上角显示：
  - 等待：提示等待大金音效；
  - 命中单件：居中显示物品名；
  - 命中组：显示“第N组大金”标题与组内全部物品明细（小紫用紫色）。
4 秒后自动回到等待状态；可整体拖动；随主题/语言即时刷新；可被安全模块
设置为防屏幕捕获，并在受保护进程运行时自动隐藏。
"""

import tkinter as tk

WIDTH = 420


class OverlayWindow:
    def __init__(self, app):
        self.app = app
        self._drag = None
        self._reset_job = None
        self.state = "wait"          # "wait" 或 items_data 的 entry dict
        self.result = None

        self.win = tk.Toplevel(app.root)
        self.win.overrideredirect(True)
        self.win.attributes("-topmost", True)
        sw = self.win.winfo_screenwidth()
        self.x = sw - WIDTH - 40
        self.y = 60
        self.win.geometry("%dx%d+%d+%d" % (WIDTH, 150, self.x, self.y))
        self.win.protocol("WM_DELETE_WINDOW", self.hide)

        self.bar = tk.Frame(self.win)
        self.bar.pack(fill="x")
        self.btn_close = tk.Button(self.bar, text="✕", relief="flat",
                                   bd=0, cursor="hand2", command=self._on_close)
        self.btn_close.pack(side="right", padx=4, pady=2)
        self.lbl_title = tk.Label(self.bar)
        self.lbl_title.pack(side="left", padx=10, pady=4)

        self.body = tk.Frame(self.win)
        self.body.pack(fill="both", expand=True)

        self.redraw()
        self.hide()

    # ------------------------------------------------------------------
    def _colors(self):
        return self.app.theme

    def redraw(self):
        t = self.app.theme
        self.win.configure(bg=t["bg"])
        self.bar.configure(bg=t["bg2"])
        self.body.configure(bg=t["bg"])
        self.lbl_title.configure(text=self.app.tr("ov_title"),
                                 fg=t["fg_dim"], bg=t["bg2"])
        self.btn_close.configure(bg=t["bg2"], fg=t["fg_dim"],
                                 activebackground=t["red"],
                                 activeforeground="#ffffff")
        # 标题栏可拖动
        for w in (self.bar, self.lbl_title):
            w.bind("<Button-1>", self._start_drag)
            w.bind("<B1-Motion>", self._do_drag)
        self._render_state()

    def _clear_body(self):
        if self._reset_job:
            try:
                self.win.after_cancel(self._reset_job)
            except Exception:
                pass
            self._reset_job = None
        for w in self.body.winfo_children():
            w.destroy()

    def _render_state(self):
        self._clear_body()
        t = self.app.theme
        if self.state == "wait":
            tk.Label(self.body, text=self.app.tr("ov_wait"),
                     fg=t["gold"], bg=t["bg"],
                     font=("Segoe UI", 18, "bold")).pack(expand=True)
            self._set_height(150)
            self._bind_drag(self.body)
            return

        entry = self.result
        if entry is None:
            return
        i18n = self.app.i18n

        if entry["kind"] == "single":
            name = i18n.item(entry["item"])
            ckey = entry.get("color", "red")
            tk.Label(self.body, text=name, fg=t.get(ckey, t["gold"]), bg=t["bg"],
                     font=("Segoe UI", 20, "bold"), wraplength=WIDTH - 40).pack(
                        expand=True, padx=16)
            self._set_height(150)
        else:
            title = i18n.group(entry["group"])
            tk.Label(self.body, text=title, fg=t["gold"], bg=t["bg"],
                     font=("Segoe UI", 15, "bold")).pack(
                        padx=14, pady=(10, 3))
            tk.Frame(self.body, bg=t["border"], height=1).pack(
                fill="x", padx=14)
            for key, ckey in entry["items"]:
                color = t.get(ckey, t["fg"])
                tk.Label(self.body, text="• " + i18n.item(key),
                         fg=color, bg=t["bg"], font=("Segoe UI", 11),
                         anchor="w").pack(anchor="w", padx=24, pady=1)

        self._bind_drag(self.body)

        # 组明细：按内容实际所需高度自适应，避免物品多时底部被裁
        if entry["kind"] == "group":
            self.win.update_idletasks()
            reqh = (self.bar.winfo_reqheight()
                    + self.body.winfo_reqheight() + 6)
            self._set_height(max(150, reqh))

        self._reset_job = self.win.after(4000, self.show_wait)

    def _set_height(self, h):
        self.win.geometry("%dx%d+%d+%d" % (WIDTH, h, self.x, self.y))

    # ---------------- 外部状态 ----------------
    def show_wait(self):
        self.state = "wait"
        self.result = None
        self._render_state()

    def show_result(self, entry):
        self.state = "result"
        self.result = entry
        self._render_state()

    def show(self):
        self.win.deiconify()
        self.win.lift()
        self.win.attributes("-topmost", True)

    def hide(self):
        self.win.withdraw()

    def _on_close(self):
        self.hide()
        if self.app.is_listening:
            self.app.stop_listening()

    # ---------------- 拖动 ----------------
    def _start_drag(self, e):
        self._drag = (e.x_root - self.win.winfo_x(),
                      e.y_root - self.win.winfo_y())

    def _do_drag(self, e):
        if self._drag:
            self.x = e.x_root - self._drag[0]
            self.y = e.y_root - self._drag[1]
            self.win.geometry("+%d+%d" % (self.x, self.y))

    def _bind_drag(self, widget):
        widget.bind("<Button-1>", self._start_drag)
        widget.bind("<B1-Motion>", self._do_drag)
        for w in widget.winfo_children():
            if w is self.btn_close:
                continue
            self._bind_drag(w)
